﻿#pragma once
#ifndef SE_ANALYSIS_READY_DATA_TOOL_DEF_H_
#define SE_ANALYSIS_READY_DATA_TOOL_DEF_H_

#include <string>
#include <vector>
#include "commontype/se_commontypedef.h"
using namespace std;

/*数据源元数据结构体（矢量数据）*/
struct VectorDataMetadataInfo
{
	/*管理信息*/
	string		strGLXX_CPMC;		// 管理信息-产品名称
	string		strGLXX_BGDW;		// 管理信息-保管单位
	string		strGLXX_SCDW;		// 管理信息-生产单位
	string		strGLXX_SCRQ;		// 管理信息-生产日期
	string		strGLXX_GXRQ;		// 管理信息-更新日期
	string		strGLXX_CPMJ;		// 管理信息-产品密级
	string		strGLXX_CPBB;		// 管理信息-产品版本
		
	/*标识信息*/
	string		strBSXX_GJZ;			// 标识信息-关键字
	string		strBSXX_SJL;			// 标识信息-数据量
	string		strBSXX_SJGS;			// 标识信息-数据格式
	string		strBSXX_SJLY;			// 标识信息-数据来源
	string		strBSXX_FFMMGF;			// 标识信息-分幅命名规范
	string		strBSXX_TM;				// 标识信息-图名
	string		strBSXX_TH;				// 标识信息-图号
	int			iBSXX_BLCFM;			// 标识信息-比例尺分母
	SE_DRect	sBSXX_SJSZFW;			// 标识信息-数据四至范围	
	string		strBSXX_ZBXT;			// 标识信息-坐标系统
	string		strBSXX_GCJZ;			// 标识信息-高程基准
	string		strBSXX_SDJZ;			// 标识信息-深度基准
	double		dBSXX_TQCBZ;			// 标识信息-椭球长半径
	double		dBSXX_TQBL;				// 标识信息-椭球扁率
	string		strBSXX_DTTY;			// 标识信息-地图投影
	int			iBSXX_ZYJX;				// 标识信息-中央经线
	double		dBSXX_BZWX;				// 标识信息-标准纬线
	string		strBSXX_ZBDW;			// 标识信息-坐标单位
		
	/*质量信息*/
	string		strZLXX_WZX;			// 质量信息-完整性
	string		strZLXX_SJZL;			// 质量信息-数据质量
		
	/*专题信息*/
	string		strZTXX_CPMC;			// 专题信息-产品名称
	string		strZTXX_BGDW;			// 专题信息-保管单位
	string		strZTXX_SCDW;			// 专题信息-生产单位
	string		strZTXX_SCRQ;			// 专题信息-生产日期
	string		strZTXX_GXRQ;			// 专题信息-更新日期
	string		strZTXX_CPMJ;			// 专题信息-产品密级
	string		strZTXX_CPBB;			// 专题信息-产品版本
	string		strZTXX_GJZ;			// 专题信息-关键字
	string		strZTXX_SJL;			// 专题信息-数据量
	string		strZTXX_SJGS;			// 专题信息-数据格式
	string		strZTXX_SJLY;			// 专题信息-数据来源
	string		strZTXX_ZYQH;			// 专题信息-作业区号
	string		strZTXX_TM;				// 专题信息-图名
	string		strZTXX_TH;				// 专题信息-图号
	int			iZTXX_BLCFM;			// 专题信息-比例尺分母
	string		strZTXX_ZBXT;			// 专题信息-坐标系统
	string		strZTXX_GCJZ;			// 专题信息-高程基准
	string		strZTXX_DTTY;			// 专题信息-地图投影
	int			iZTXX_DGJ;				// 专题信息-等高距
	string		strZTXX_ZQSM;			// 专题信息-政区说明

	VectorDataMetadataInfo()
	{
		/*管理信息*/
		strGLXX_CPMC = "";				
		strGLXX_BGDW = "";		
		strGLXX_SCDW = "";	
		strGLXX_SCRQ = "";		
		strGLXX_GXRQ = "";		
		strGLXX_CPMJ = "";	
		strGLXX_CPBB = "";		

		/*标识信息*/
		strBSXX_GJZ = "";
		strBSXX_SJL = "";
		strBSXX_SJGS = "";
		strBSXX_SJLY = "";
		strBSXX_FFMMGF = "";
		strBSXX_TM = "";
		strBSXX_TH = "";
		iBSXX_BLCFM = 0;
		strBSXX_ZBXT = "";
		strBSXX_GCJZ = "";
		strBSXX_SDJZ = "";
		dBSXX_TQCBZ = 0;
		dBSXX_TQBL = 0;
		strBSXX_DTTY = "";
		iBSXX_ZYJX = 0;
		dBSXX_BZWX = 0;
		strBSXX_ZBDW = "";

		/*质量信息*/
		strZLXX_WZX = "";			
		strZLXX_SJZL = "";			

		/*专题信息*/
		strZTXX_CPMC = "";			
		strZTXX_BGDW = "";			
		strZTXX_SCDW = "";		
		strZTXX_SCRQ = "";			
		strZTXX_GXRQ = "";		
		strZTXX_CPMJ = "";			
		strZTXX_CPBB = "";			
		strZTXX_GJZ = "";			
		strZTXX_SJL = "";			
		strZTXX_SJGS = "";			
		strZTXX_SJLY = "";			
		strZTXX_ZYQH = "";		
		strZTXX_TM = "";				
		strZTXX_TH = "";			
		iZTXX_BLCFM = 0;			
		strZTXX_ZBXT = "";			
		strZTXX_GCJZ = "";			
		strZTXX_DTTY = "";			
		iZTXX_DGJ = 0;				
		strZTXX_ZQSM = "";			
	}
};


/*栅格分析就绪数据检查项结构体*/
struct RaterARDCheckItems
{
	/*逻辑一致性检查项*/
	bool			bCanBeOpened;			// 数据是否能打开
	bool			bFormatIsTrue;			// 数据格式是否正确
	bool			bTypeIsTrue;			// 数据类型是否正确


	/*数据完整性检查项*/
	bool			bDataIsCompleted;		// 数据是否完整
	bool			bMetaDataIsTrue;		// 元数据是否符合模板要求


	RaterARDCheckItems()
	{
		bCanBeOpened = false;
		bFormatIsTrue = false;
		bTypeIsTrue = false;
		bDataIsCompleted = false;
		bMetaDataIsTrue = false;
	}
};


/*矢量分析就绪数据检查项结构体*/
struct VectorARDCheckItems
{
	/*逻辑一致性检查项*/
	bool			bCanBeOpened;			// 数据是否能打开
	bool			bFormatIsTrue;			// 数据格式是否正确
	bool			bAttributeIsTrue;		// 属性值是否符合规范
	bool			bAttributeTypeIsTrue;	// 属性类型是否符合规范

	/*数据完整性检查项*/
	bool			bDataIsCompleted;		// 数据是否完整
	bool			bMetaDataIsTrue;		// 元数据是否符合模板要求
	bool			bAttributeIsCompleted;	// 属性是否缺失

	VectorARDCheckItems()
	{
		bCanBeOpened = false;
		bFormatIsTrue = false;
		bAttributeIsTrue = false;
		bAttributeTypeIsTrue = false;
		bDataIsCompleted = false;
		bMetaDataIsTrue = false;
		bAttributeIsCompleted = false;
	}
};



#endif // SE_ANALYSIS_READY_DATA_TOOL_DEF_H_