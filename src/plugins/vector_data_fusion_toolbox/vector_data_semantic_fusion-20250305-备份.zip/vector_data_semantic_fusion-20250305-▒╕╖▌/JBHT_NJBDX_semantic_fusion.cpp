#pragma region "1 包含头文件（减少重复）"
/************ C++/STL ************/
#include <string>
#include <filesystem>
#include <set>
#include <iostream>
#include <regex>
#include <fstream>

/************ GDAL/OGR ************/
#include "ogrsf_frmts.h"
#include "gdal_priv.h"
#include "cpl_conv.h"
#include "cpl_string.h"
#include "ogr_spatialref.h"
#include "ogr_feature.h"

/************ spdlog ************/
#include <spdlog/spdlog.h>
#include <spdlog/sinks/basic_file_sink.h>

/************ Qt ************/
#include <QFile>
#include <QCoreApplication>
#include <QFileDialog>
#include <QMessageBox>
#include <QDebug>
#include <QString>

/************ QGIS 基础 ************/
#include "qgsapplication.h"
#include "qgsgui.h"
#include "qgssettings.h"
#include <QgsMessageLog.h>

/************ QGIS - 表达式、要素、图层操作 ************/
#include "qgsexpression.h"
#include "qgsexpressioncontext.h"
#include "qgsexpressioncontextutils.h"
#include "qgsfeature.h"
#include "qgsfields.h"
#include "qgsfield.h"

/************ 项目头文件 ************/
#include "JBHT_NJBDX_semantic_fusion.h"




#include <iostream>
#include <memory>
#include <algorithm>
#include <cctype>
#include <spdlog/spdlog.h>
#include <ogr_spatialref.h>
#include <ogr_geometry.h>
#include <ogr_feature.h>
#include <ogr_api.h>

#pragma endregion

#pragma region "2 构造函数、析构函数"
qgs_JBHT_NJBDX_semantic_fusion::qgs_JBHT_NJBDX_semantic_fusion(QWidget* parent, Qt::WindowFlags fl)
	: QDialog(parent, fl),
  m_input_data_path(""),
  m_output_data_path(""),
  m_counter_total(0),
  m_counter_succeeded(0)
{
	ui.setupUi(this);

	QgsGui::enableAutoGeometryRestore(this);

	connect(ui.Button_input_data_view, &QPushButton::clicked, this, &qgs_JBHT_NJBDX_semantic_fusion::Button_input_data_view);
	connect(ui.Button_output_data_view, &QPushButton::clicked, this, &qgs_JBHT_NJBDX_semantic_fusion::Button_output_data_view);
	connect(ui.Button_OK, &QPushButton::clicked, this, &qgs_JBHT_NJBDX_semantic_fusion::Button_OK);
	connect(ui.Button_Cancel, &QPushButton::clicked, this, &qgs_JBHT_NJBDX_semantic_fusion::Button_Cancel);

  restore_states();
}

qgs_JBHT_NJBDX_semantic_fusion::~qgs_JBHT_NJBDX_semantic_fusion()
{
  save_states();
}
#pragma endregion

#pragma region "3 类成员对象set、get函数"
//  获取输入数据目录成员函数
QString qgs_JBHT_NJBDX_semantic_fusion::get_m_input_data_path()
{
  return m_input_data_path;
}

//  获取输出数据目录成员函数
QString qgs_JBHT_NJBDX_semantic_fusion::get_m_output_data_path()
{
  return m_output_data_path;
}

//  设置输入数据目录成员函数（目前还没有用到）
void qgs_JBHT_NJBDX_semantic_fusion::set_m_input_data_path(const std::string& input_data_path)
{
  m_input_data_path = QString::fromStdString(input_data_path);
}

//  设置输出数据目录成员函数（目前还没有用到）
void qgs_JBHT_NJBDX_semantic_fusion::set_m_output_data_path(const std::string& output_data_path)
{
  m_output_data_path = QString::fromStdString(output_data_path);
}

//  恢复保存参数
void qgs_JBHT_NJBDX_semantic_fusion::restore_states()
{
  //  从上一次保存的路径数据中得到输入输出数据
  QgsSettings settings;
  //  指定从Plugins节读取设置
  settings.beginGroup("vector_data_JBHT_NJBDX_semantic_fusion");
  this->m_input_data_path = settings.value(QStringLiteral("vector_data_JBHT_NJBDX_semantic_fusion/m_input_data_path"), QDir::homePath()).toString();
  this->m_output_data_path = settings.value(QStringLiteral("vector_data_JBHT_NJBDX_semantic_fusion/m_output_data_path"), QDir::homePath()).toString();
  //  结束分组，非常重要，确保设置正确保存在指定的节中
  settings.endGroup();

  //  填充输入输出数据路径，显示在交互界面上
  ui.lineEdit_input_data_path->setText(m_input_data_path);
  ui.lineEdit_output_data_path->setText(m_output_data_path);
}

//  保存参数
void qgs_JBHT_NJBDX_semantic_fusion::save_states()
{
  QgsSettings settings;
  // 指定设置保存到Plugins节
  settings.beginGroup("vector_data_JBHT_NJBDX_semantic_fusion");
  settings.setValue(QStringLiteral("vector_data_JBHT_NJBDX_semantic_fusion/m_input_data_path"), m_input_data_path);
  settings.setValue(QStringLiteral("vector_data_JBHT_NJBDX_semantic_fusion/m_output_data_path"), m_output_data_path);
  // 结束分组，非常重要，确保设置正确保存在指定的节中
  settings.endGroup();
}
#pragma endregion

#pragma region "4 私有槽函数"

void qgs_JBHT_NJBDX_semantic_fusion::Button_input_data_view()
{
  //  选择文件夹
  QString curPath = m_input_data_path;
  QString dlgTile = QObject::tr("JBHT--->NJBDX：请选择语义融合工具输入数据源所在的目录位置");
  QString selectedDir = QFileDialog::getExistingDirectory(
    this,
    dlgTile,
    curPath,
    QFileDialog::ShowDirsOnly);

  if (!selectedDir.isEmpty())
  {
    ui.lineEdit_input_data_path->setText(selectedDir);
    //  需要将读取进来的路径字符串进行规范化
    m_input_data_path = normalizePath(selectedDir);
  }
}

void qgs_JBHT_NJBDX_semantic_fusion::Button_output_data_view()
{
  //  选择文件夹
  QString curPath = m_output_data_path;
  QString dlgTile = QObject::tr("JBHT--->NJBDX：请选择语义融合处理后数据存放的目录位置");
  QString selectedDir = QFileDialog::getExistingDirectory(
    this,
    dlgTile,
    curPath,
    QFileDialog::ShowDirsOnly);

  if (!selectedDir.isEmpty())
  {
    ui.lineEdit_output_data_path->setText(selectedDir);
    //  需要将读取进来的路径字符串进行规范化
    m_output_data_path = normalizePath(selectedDir);
  }
}

void qgs_JBHT_NJBDX_semantic_fusion::Button_OK()
{
  /*
  功能说明：
    1、当UI界面中的“确定”按钮被点击的时候，对JBHT--->NJBDX处理开始
    2、UI界面中的输入和输出路径作为该工具的输入、输出路径参数

  算法流程：
    1. 验证用户输入的数据源路径和保存转换后数据的路径。
    2. 加载JBHT--->NJBDX涉及到的四个配置文件。
    3. 使用提取和验证的数据执行最终的转换过程。
  */

  /*
    在点击确定的时候说明JBHT--->NJBDX转化开始了，在后面的语义融合过程中可能会出现异常导致程序不能顺利进行到最后,
  因此首先在这里将界面参数保存下来。
  */
  save_states();

#pragma region "（第一步）判断输入数据路径、输出数据路径在文件系统中是否存在"
  //  更新成员变量
  m_input_data_path = normalizePath(ui.lineEdit_input_data_path->text());
  m_output_data_path = normalizePath(ui.lineEdit_output_data_path->text());

  //  检查目录是否存在
  if (!is_exist_directory(get_m_input_data_path()))
  {
    showMessageBox(tr("矢量数据语义融合（JBHT--->NJBDX）"), tr("输入数据目录不存在，请重新输入！"));
    return;
  }
  if (!is_exist_directory(get_m_output_data_path()))
  {
    showMessageBox(tr("矢量数据语义融合（JBHT--->NJBDX）"), tr("输出数据目录不存在，请重新输入！"));
    return;
  }
#pragma endregion 

#pragma region "（第二步）获取输入数据路径、输出数据的路径"

  //  获取输入数据路径
  QString qstr_input_data_path = get_m_input_data_path();
  std::string str_input_data_path = qstr_input_data_path.toUtf8().toStdString();

  //  获取数据保存目录
  QString qstr_output_data_path = get_m_output_data_path();
  std::string str_output_data_path = qstr_output_data_path.toUtf8().toStdString();

  //  获取输入路径下中的分幅数据列表
  QStringList qstr_input_data_path_list = get_sub_directories(qstr_input_data_path);

#pragma endregion

#pragma region "（第三步）读取JBHT--->NJBDX配置文件，并且检查五个配置文件是否有效"
  //  获取程序所在目录，并且对路径字符串统一化
  QString appDirPath = normalizePath(QCoreApplication::applicationDirPath());
  //  创建指向config文件夹的QDir对象
  QDir configDir(appDirPath);
  //  切换到config文件夹
  if (!configDir.cd("DLHJ_Vector_Data_Semantic_Fusion_Config"))
  {
    showMessageBox(tr("矢量数据语义融合（JBHT--->NJBDX）"), tr("配置目录 'DLHJ_Vector_Data_Semantic_Fusion_Config' 不存在！"));
    return;
  }

  //  拼接各个配置文件的完整路径
  QString configFilePath1 = configDir.filePath("JBHT/JBHT_Layers_Fields_Info.json");
  QString configFilePath2 = configDir.filePath("JBHT/JBHT_Layers_Mapping_NJBDX_Layers.json");
  QString configFilePath3 = configDir.filePath("JBHT/JBHT_Classification_Code_Conditional_Mapping_Lists.json");
  QString configFilePath4 = configDir.filePath("JBHT/JBHT_Other_Fields_Mapping_NJBDX_Other_Fields.json");
  QString configFilePath5 = configDir.filePath("NJBDX/NJBDX_Layers_Fields_Info.json");
  //  检查配置文件路径是否存在
  if (!is_exist_file(configFilePath1))
  {
    showMessageBox(tr("矢量数据语义融合（JBHT--->NJBDX）"), tr("配置文件JBHT_Layers_Fields_Info.json不存在！"));
    return;
  }
  if (!is_exist_file(configFilePath2))
  {
    showMessageBox(tr("矢量数据语义融合（JBHT--->NJBDX）"), tr("配置文件JBHT_Layers_Mapping_NJBDX_Layers.json不存在！"));
    return;
  }
  if (!is_exist_file(configFilePath3))
  {
    showMessageBox(tr("矢量数据语义融合（JBHT--->NJBDX）"), tr("配置文件JBHT_Classification_Code_Conditional_Mapping_Lists.json不存在！"));
    return;
  }
  if (!is_exist_file(configFilePath4))
  {
    showMessageBox(tr("矢量数据语义融合（JBHT--->NJBDX）"), tr("配置文件JBHT_Other_Fields_Mapping_NJBDX_Other_Fields.json不存在！"));
    return;
  }
  if (!is_exist_file(configFilePath5))
  {
    showMessageBox(tr("矢量数据语义融合（JBHT--->NJBDX）"), tr("配置文件NJBDX_Layers_fields_Info.json不存在！"));
    return;
  }

  //  创建或获取一个日志器
  std::shared_ptr<spdlog::logger> read_config_logger = spdlog::get("read_config_logger");
  if (!read_config_logger)
  {
    //  使用 std::unique_ptr
    auto formatter = std::make_unique<spdlog::pattern_formatter>("[%Y-%m-%d %H:%M:%S.%e] [%l] %v");

#pragma region "处理日志文件路径的字符集编码问题，在windows平台上文件系统使用的是UTF-16字符集编码"
    //  拼接配置文件检查日志输出目录
    QString config_check_log_dir = appDirPath + "/DLHJ_Vector_Data_Semantic_Fusion_Config";
    //  创建目录操作对象
    QDir outputDir(config_check_log_dir);
    //  这个目录需要存在，因为相关的配置文件保存在这个目录中
    if (!outputDir.exists())
    {
        showMessageBox(tr("矢量数据语义融合（JBHT--->NJBDX）"), tr("配置目录DLHJ_Vector_Data_Semantic_Fusion_Config不存在！"));
        return;
    }
    //  拼接日志文件路径，返回“输出目录/config_check_log.txt”
    QString config_check_log_path = outputDir.absoluteFilePath("config_check_log.txt");

#pragma endregion

    //  创建文件日志器
    read_config_logger = spdlog::basic_logger_mt(
      "read_config_logger",
      normalizePath(config_check_log_path).toLocal8Bit().toStdString(),
      true);
    //  使用 std::move(...) 传递 formatter
    read_config_logger->set_formatter(std::move(formatter));
    //  设置日志级别为最低级别，以便记录所有级别的日志
    read_config_logger->set_level(spdlog::level::trace);
    //  设置在任何级别时都刷新
    read_config_logger->flush_on(spdlog::level::trace);
    //  记录初始化信息
    read_config_logger->info("读取配置文件日志开始！");
  }
  else
  {
    read_config_logger->info("读取配置文件日志开始！");
  }

  //  读取配置文件内容
  JBHT_Layers_Fields_Info_Json_t JBHT_Layers_Fields_Info_Json_entity = readJBHT_Layers_Fields_Info_Json(
    normalizePath(configFilePath1).toUtf8(),
    read_config_logger);
  //  检查配置文件是否有效
  if (!checkJBHT_Layers_Fields_Info_Json(JBHT_Layers_Fields_Info_Json_entity, read_config_logger))
  {
    showMessageBox(tr("矢量数据语义融合（JBHT--->NJBDX）"), tr("JBHT_Layers_Fields_Info.json配置文件存在问题，请检查！"));
    return;
  }

  JBHT_Layers_Mapping_NJBDX_Layers_Json_t JBHT_Layers_Mapping_NJBDX_Layers_Json_entity = readJBHT_Layers_Mapping_NJBDX_Layers_Json(
    normalizePath(configFilePath2).toUtf8(),
    read_config_logger);
  if (!checkJBHT_Layers_Mapping_NJBDX_Layers_Json(JBHT_Layers_Mapping_NJBDX_Layers_Json_entity, read_config_logger))
  {
    showMessageBox(tr("矢量数据语义融合（JBHT--->NJBDX）"), tr("JBHT_Layers_Mapping_NJBDX_Layers.json配置文件存在问题，请检查！"));
    return;
  }


  JBHT_Classification_Code_Conditional_Mapping_Lists_Json_t JBHT_Classification_Code_Conditional_Mapping_Lists_Json_entity = readJBHT_Classification_Code_Conditional_Mapping_Lists_Json(
    normalizePath(configFilePath3).toUtf8(),
    read_config_logger);
  if (!checkJBHT_Classification_Code_Conditional_Mapping_Lists_Json(JBHT_Classification_Code_Conditional_Mapping_Lists_Json_entity, read_config_logger))
  {
    showMessageBox(tr("矢量数据语义融合（JBHT--->NJBDX）"), tr("JBHT_Classification_Code_Conditional_Mapping_Lists.json配置文件存在问题，请检查！"));
    return;
  }

  JBHT_Other_Fields_Mapping_NJBDX_Other_Fields_Json_t JBHT_Other_Fields_Mapping_NJBDX_Other_Fields_Json_entity = readJBHT_Other_Fields_Mapping_NJBDX_Other_Fields_Json(
    normalizePath(configFilePath4).toUtf8(),
    read_config_logger);
  if (!checkJBHT_Other_Fields_Mapping_NJBDX_Other_Fields_Json(JBHT_Other_Fields_Mapping_NJBDX_Other_Fields_Json_entity, read_config_logger))
  {
    showMessageBox(tr("矢量数据语义融合（JBHT--->NJBDX）"), tr("JBHT_Other_Fields_Mapping_NJBDX_Other_Fields.json配置文件存在问题，请检查！"));
    return;
  }

  JBHT_NJBDX_Layers_Fields_Info_Json_t NJBDX_Layers_Fields_Info_Json_entity = JBHT_readNJBDX_Layers_Fields_Info_Json(
    normalizePath(configFilePath5).toUtf8(),
    read_config_logger);
  if (!checkNJBDX_Layers_Fields_Info_Json(NJBDX_Layers_Fields_Info_Json_entity, read_config_logger))
  {
    showMessageBox(tr("矢量数据语义融合（JBHT--->NJBDX）"), tr("NJBDX_layers_fields_info.json配置文件存在问题，请检查！"));
    return;
  }

#pragma endregion

#pragma region "（第四步）循环从分幅数据中处理JBHT--->NJBDX语义融合"

#pragma region "1、获取分幅数据的绝对路径"
  //	创建临时变量用来存储输入数据路径中多个分幅数据的绝对路径
  std::vector<std::string> vstr_input_frame_data_path;
  vstr_input_frame_data_path.clear();

  //  如果输入路径中没有分幅数据，则将输入路径保存到这个临时变量中，相当于单个分幅数据
  if (qstr_input_data_path_list.size() == 0)
  {
    //	将输入路径保存到临时变量中以供后续使用
    vstr_input_frame_data_path.push_back(str_input_data_path);
  }
  else
  {
    //	将所有子目录的绝对路径添加到临时变量中以供后续使用
    for (int i = 0; i < qstr_input_data_path_list.size(); i++)
    {
      std::string strPathTemp = normalizePath(qstr_input_data_path_list[i]).toUtf8().toStdString();
      vstr_input_frame_data_path.push_back(strPathTemp);
    }
  }

#pragma endregion

#pragma region "2、JBHT--->NJBDX语义融合处理"

  //  JBHT--->NJBDX
  try
  {
      JBHT2NJBDX(
      vstr_input_frame_data_path,
      str_output_data_path,
      JBHT_Layers_Fields_Info_Json_entity,
      JBHT_Layers_Mapping_NJBDX_Layers_Json_entity,
      JBHT_Classification_Code_Conditional_Mapping_Lists_Json_entity,
      JBHT_Other_Fields_Mapping_NJBDX_Other_Fields_Json_entity,
      NJBDX_Layers_Fields_Info_Json_entity);
  }
  catch (const std::exception& e)
  {
    showMessageBox(tr("矢量数据语义融合（JBHT--->NJBDX）"), QString::fromStdString(e.what()));
    return;
  }
  catch (...)
  {
    showMessageBox(tr("矢量数据语义融合（JBHT--->NJBDX）"), tr("发生未知异常！"));
    return;
  }

  //  显示统计信息
  {
    //  记录日志
    QMessageBox msgBox1;
    msgBox1.setWindowTitle(tr("矢量语义融合处理（JBHT--->NJBDX）"));
    //  拼接显示信息
    QString qstrText = tr("一共") + QString::number(m_counter_total)
      + tr("幅分幅数据；其中成功处理了") + QString::number(m_counter_succeeded)
      + tr("幅分幅数据；失败了") + QString::number(m_counter_total - m_counter_succeeded)
      + tr("幅分幅数据。详细信息请查看日志文件！");
    msgBox1.setText(qstrText);
    msgBox1.setStandardButtons(QMessageBox::Ok);
    msgBox1.setDefaultButton(QMessageBox::Ok);
    msgBox1.exec();
  
    //  重置总图幅计数器、成功处理图幅计数器（目前使用成员变量的方式，如果修改成临时变量的方式则不需要在这里进行重置）
    m_counter_total = 0;
    m_counter_succeeded = 0;

    return;
  }
#pragma endregion

#pragma endregion

}

void qgs_JBHT_NJBDX_semantic_fusion::Button_Cancel()
{
  reject();
}

#pragma endregion

#pragma region "6 类辅助成员函数"
//  判断目录是否存在
bool qgs_JBHT_NJBDX_semantic_fusion::is_exist_directory(const QString& qstr_directory_path)
{
  QDir dir(qstr_directory_path);
  return dir.exists();
}

//  判断文件是否存在
bool qgs_JBHT_NJBDX_semantic_fusion::is_exist_file(const QString& qstr_file_path)
{
  return QFile::exists(qstr_file_path);
}

//  获取指定目录中的多个子目录
QStringList qgs_JBHT_NJBDX_semantic_fusion::get_sub_directories(const QString& file_directory_path)
{
  QStringList dirPaths;
  QDir QDir_file_directory_path(file_directory_path);
  QFileInfoList file_info_list_in_QDir_file_directory_path = QDir_file_directory_path.entryInfoList(QDir::Dirs | QDir::NoDotAndDotDot);
  QFileInfo tempFileInfo;
  foreach(tempFileInfo, file_info_list_in_QDir_file_directory_path)
  {
    dirPaths << tempFileInfo.absoluteFilePath();
  }
  return dirPaths;
}

//  自定义信息提示框
void qgs_JBHT_NJBDX_semantic_fusion::showMessageBox(const QString& title, const QString& text)
{
  QMessageBox msgBox;
  msgBox.setWindowTitle(title);
  msgBox.setText(text);
  msgBox.setStandardButtons(QMessageBox::Yes);
  msgBox.setDefaultButton(QMessageBox::Yes);
  msgBox.exec();
}

//  辅助函数：转换路径为统一格式
QString qgs_JBHT_NJBDX_semantic_fusion::normalizePath(const QString& path)
{
  // 将反斜杠替换为正斜杠
  QString normalizedPath = path;
  normalizedPath.replace("\\", "/");
  return normalizedPath;
}
#pragma endregion

#pragma region "7 JBHT--->NJBDX内部函数"

void qgs_JBHT_NJBDX_semantic_fusion::JBHT2NJBDX(
  const std::vector<std::string>& vstr_input_frame_data_path,
  const std::string& str_output_data_path,
  const JBHT_Layers_Fields_Info_Json_t& JBHT_Layers_Fields_Info_Json_entity,
  const JBHT_Layers_Mapping_NJBDX_Layers_Json_t& JBHT_Layers_Mapping_NJBDX_Layers_Json_entity,
  const JBHT_Classification_Code_Conditional_Mapping_Lists_Json_t& JBHT_Classification_Code_Conditional_Mapping_Lists_Json_entity,
  const JBHT_Other_Fields_Mapping_NJBDX_Other_Fields_Json_t& JBHT_Other_Fields_Mapping_NJBDX_Other_Fields_Json_entity,
  const JBHT_NJBDX_Layers_Fields_Info_Json_t& NJBDX_Layers_Fields_Info_Json_entity)
{
  /*
  Note:杨小兵-2025-01-15

  1、函数功能
    1.1 字符串数组中存储的是多个分幅数据的绝对路径，每一个分幅数据中是由多个图层构成的
    1.2 该函数将会循环将每个分幅数据中的图层进行语义融合处理
  2、算法流程
    2.1 获取当前分幅数据绝对路径
    2.2 对当前分幅数据进行语义融合处理
    2.3 对处理结果进行判断
  3、前提假设
    3.1 上述传入的七个参数都是有效的（由调用者保证）
  */

  //  获取分幅数据的数量
  size_t size = vstr_input_frame_data_path.size();

  //  更新总图幅计数器
  m_counter_total = size;

  //  循环处理
  for (size_t i = 0; i < size; i++)
  {
    try {
       //  记录当前语义融合处理的结果标志
       int iresult_single_frame_data;
       //  对当前分幅数据进行语义融合处理
       iresult_single_frame_data = JBHT2NJBDX_Single_Frame_Data(
         vstr_input_frame_data_path[i],
         str_output_data_path,
         JBHT_Layers_Fields_Info_Json_entity,
         JBHT_Layers_Mapping_NJBDX_Layers_Json_entity,
         JBHT_Classification_Code_Conditional_Mapping_Lists_Json_entity,
         JBHT_Other_Fields_Mapping_NJBDX_Other_Fields_Json_entity,
         NJBDX_Layers_Fields_Info_Json_entity);
       //	如果当前分幅数据语义融合处理失败则需要将日志信息输出到QGIS日志板上
       if (iresult_single_frame_data != 0)
       {
         QString qstrMsg = QString("分幅数据：%1 矢量数据语义融合失败！")
           .arg(QString::fromStdString(vstr_input_frame_data_path[i]));
         QString qstrTag = "JBHT--->NJBDX";
         QgsMessageLog::logMessage(qstrMsg, qstrTag, Qgis::Critical);

         //  继续处理其他分幅数据
         continue;
       }
       else
       {
         //  更新成功计数器
         m_counter_succeeded++;
       }
    }
    catch (const std::exception& e)
    {
      // 使用 QString 进行字符串拼接
      QString qstrMsg = QString("分幅数据：%1 处理时发生异常：%2")
        .arg(QString::fromStdString(vstr_input_frame_data_path[i]))
        .arg(QString::fromStdString(e.what()));
      QString qstrTag = "JBHT--->NJBDX";
      QgsMessageLog::logMessage(qstrMsg, qstrTag, Qgis::Critical);
      // 继续处理下一个分幅数据
      continue;
    }
    catch (...)
    {
      QString qstrMsg = QString("分幅数据：%1 处理时发生未知异常！")
        .arg(QString::fromStdString(vstr_input_frame_data_path[i]));
      QString qstrTag = "JBHT--->NJBDX";
      QgsMessageLog::logMessage(qstrMsg, qstrTag, Qgis::Critical);
      // 继续处理下一个分幅数据
      continue;
    }
  }

  //  成功处理返回
  return;
}

int qgs_JBHT_NJBDX_semantic_fusion::JBHT2NJBDX_Single_Frame_Data(
  const std::string& single_frame_data_path,
  const std::string& str_output_data_path,
  const JBHT_Layers_Fields_Info_Json_t& JBHT_Layers_Fields_Info_Json_entity,
  const JBHT_Layers_Mapping_NJBDX_Layers_Json_t& JBHT_Layers_Mapping_NJBDX_Layers_Json_entity,
  const JBHT_Classification_Code_Conditional_Mapping_Lists_Json_t& JBHT_Classification_Code_Conditional_Mapping_Lists_Json_entity,
  const JBHT_Other_Fields_Mapping_NJBDX_Other_Fields_Json_t& JBHT_Other_Fields_Mapping_NJBDX_Other_Fields_Json_entity,
  const JBHT_NJBDX_Layers_Fields_Info_Json_t& NJBDX_Layers_Fields_Info_Json_entity)
{
  /*
  Note:杨小兵-2025-01-15

  1、函数功能：实现JBHT单个分幅数据的语义融合处理
  2、算法流程
    2.1 将单个分幅数据目录路径下的所有图层读取到内存当中
    2.2 将所有图层的相关信息读取到自定义数据结构中（图层名称、图层类型、图层指针等等）
    2.3 循环对每一个图层进行转化操作
  3、前提假设
    3.1 上述传入的七个参数都是有效的（由调用者保证）
  */

#pragma region "第一步：创建输出目录、日志器、日志文件"
  //  创建临时变量用来保存最终的输出目录
  std::string str_single_output_data_path = "";
  //  创建一个日志器用来写入日志信息
  std::shared_ptr<spdlog::logger> single_frame_data_logger = nullptr;

  try {

    //  将 std::string 转为 QString（输入为 UTF-8 编码）
    QString qSingleFrameDataPath = QString::fromStdString(single_frame_data_path);
    QString qOutputDataPath = QString::fromStdString(str_output_data_path);

    //  1. 检查输入路径是否存在且为目录
    QDir inputDir(qSingleFrameDataPath);
    if (!inputDir.exists() || !QFileInfo(qSingleFrameDataPath).isDir())
    {
      QString qstrMsg = QString("在函数 %1 中发生异常：输入的分幅数据路径不存在或不是一个目录：%2")
        .arg(__FUNCTION__)
        .arg(qSingleFrameDataPath);
      QgsMessageLog::logMessage(qstrMsg, "JBHT--->NJBDX", Qgis::Critical);
      return -1;
    }

    //  2. 获取目录名，比如 DN09490622，QDir::dirName() 返回当前 QDir 对应路径的最后一级目录名
    QString frame_dir_name = inputDir.dirName();
    //  3. 拼接输出目录名称
    QString output_dir_name = "JBHT2NJBDX_" + frame_dir_name;

    //  拼接最终完整输出目录
    QString qSingleOutputDataPath = qOutputDataPath + "/" + output_dir_name;
    //  同步回到 std::string，后面可能 GDAL/其他逻辑还要用
    str_single_output_data_path = qSingleOutputDataPath.toStdString();

    //  4. 则创建最终的输出目录
    QDir outputDir(qSingleOutputDataPath);
    if (!outputDir.exists())
    {
      //  mkpath()：若多级目录不存在会一并创建
      if (!outputDir.mkpath(qSingleOutputDataPath))
      {
        QString qstrMsg = QString("在函数 %1 中发生异常：无法创建输出目录：%2")
          .arg(__FUNCTION__)
          .arg(qSingleOutputDataPath);
        QgsMessageLog::logMessage(qstrMsg, "JBHT--->NJBDX", Qgis::Critical);
        return -2;
      }
    }

    //  5. 拼接日志文件路径，outputDir.absoluteFilePath("log.txt") 返回“输出目录/log.txt”
    QString qLogFilePath = outputDir.absoluteFilePath("log.txt");


    try
    {
      // 使用 std::unique_ptr
      auto formatter = std::make_unique<spdlog::pattern_formatter>("[%Y-%m-%d %H:%M:%S.%e] [%l] %v");

      /*
        创建文件日志器：需要 std::string 路径(最后一个参数 truncate = false 表示追加)
      不再用 toUtf8()，改用 toLocal8Bit() 得到本地编码。
      */
      std::string log_file_path_std = qLogFilePath.toLocal8Bit().toStdString();
      single_frame_data_logger = spdlog::basic_logger_mt(
        "single_frame_logger_" + frame_dir_name.toStdString(),
        log_file_path_std,
        true
      );

      //  使用 std::move(...) 传递 formatter
      single_frame_data_logger->set_formatter(std::move(formatter));

      //  设置日志级别为最低级别，以便记录所有级别的日志
      single_frame_data_logger->set_level(spdlog::level::trace);

      //  设置在任何级别时都刷新
      single_frame_data_logger->flush_on(spdlog::level::trace);

      //  记录初始化信息
      single_frame_data_logger->info("*****************************************开始处理分幅数据：{}*****************************************", single_frame_data_path);
      //  保证输出的字符串的字符集编码都是UTF-8
      single_frame_data_logger->info("日志文件路径：{}", qLogFilePath.toUtf8().toStdString());

    }
    catch (const spdlog::spdlog_ex& ex)
    {
      QString qstrMsg = QString("在函数 %1 中发生异常：无法初始化日志器：%2")
        .arg(__FUNCTION__)
        .arg(QString::fromStdString(ex.what()));
      QgsMessageLog::logMessage(qstrMsg, "JBHT--->NJBDX", Qgis::Critical);
      return -3;
    }

  }
  catch (const std::exception& e)
  {
    QString qstrMsg = QString("在函数 %1 处理中发生异常：%2")
      .arg(__FUNCTION__)
      .arg(QString::fromStdString(e.what()));
    QgsMessageLog::logMessage(qstrMsg, "JBHT--->NJBDX", Qgis::Critical);
    return -4;
  }
  catch (...)
  {
    QString qstrMsg = QString("在函数 %1 处理中发生未知异常！")
      .arg(__FUNCTION__);
    QgsMessageLog::logMessage(qstrMsg, "JBHT--->NJBDX", Qgis::Critical);
    return -5;
  }

#pragma endregion

#pragma region "第二步：设置GDAL并且获取驱动器"
  //  这告诉 GDAL 文件名不使用系统的本地编码（在 Windows 上为 UTF-16），而是UTF-8编码的路径字符串
  CPLSetConfigOption("GDAL_FILENAME_IS_UTF8", "YES");
  //  将 SHAPE_ENCODING 设置为空字符串 "" 表示 GDAL 将尝试自动检测 DBF 文件的编码，或者使用默认编码。
  CPLSetConfigOption("SHAPE_ENCODING", "");
  //  注册所有 GDAL 驱动
  GDALAllRegister();
  const char* pszShpDriverName = "ESRI Shapefile";
  GDALDriver* poShpDriver;
  poShpDriver = GetGDALDriverManager()->GetDriverByName(pszShpDriverName);
  if (poShpDriver == NULL)
  {
    single_frame_data_logger->error("函数[{}]：获取ESRI Shapefile矢量驱动器失败。", __FUNCTION__);
    single_frame_data_logger->info("*****************************************结束处理分幅数据：{}*****************************************", single_frame_data_path);
    return -6;
  }
#pragma endregion

#pragma region "第三步：将JBHT数据所有图层的相关信息读取到自定义数据结构中"

  //  利用矢量驱动器打开当前分幅数据目录路径下的矢量数据,以只读数据的方式打开数据
  GDALDataset* poSingleFrameJBHTDataSet = (GDALDataset*)GDALOpenEx(single_frame_data_path.c_str(), GDAL_OF_READONLY, NULL, NULL, NULL);
  //  文件不存在或打开失败
  if (poSingleFrameJBHTDataSet == NULL)
  {
    single_frame_data_logger->error("函数[{}]：使用GDALOpenEx打开数据集{}失败。", __FUNCTION__, single_frame_data_path);
    single_frame_data_logger->info("*****************************************结束处理分幅数据：{}*****************************************", single_frame_data_path);
    return -7;
  }

  //	创建变量用来存储JBHT分幅数据相关信息
  JBHT_single_frame_data_all_layers_info_t JBHT_single_frame_data_all_layers_info_entity;
  //  读取当前分幅数据矢量图层的信息：分幅数据路径、数据集指针；对每个图层而言记录信息有：图层名字、图层类型、图层指针、图层空间参考
  JBHT_Create_single_frame_data_all_layers_info(
    poSingleFrameJBHTDataSet,
    JBHT_single_frame_data_all_layers_info_entity,
    single_frame_data_logger);
  //  检查数据集中的图层是否为空
  if (!JBHT_Check_single_frame_data_all_layers_info(JBHT_single_frame_data_all_layers_info_entity, single_frame_data_logger))
  {
    single_frame_data_logger->error("函数[{}]：分幅数据{}中的有效矢量图层为空。", __FUNCTION__, single_frame_data_path);
    //  需要将已经打开的数据集关闭以释放内存资源
    JBHT_Close_single_frame_data_all_layers_info(JBHT_single_frame_data_all_layers_info_entity);
    single_frame_data_logger->info("*****************************************结束处理分幅数据：{}*****************************************", single_frame_data_path);
    return -8;
  }

#pragma endregion

#pragma region "第四步：根据JBHT实际数据和图层映射关系创建NJBDX数据集信息到自定义数据结构中"
  //  创建变量用来存储NJBDX分幅数据相关信息
  JBHT_NJBDX_single_frame_data_all_layers_info_t NJBDX_single_frame_data_all_layers_info_entity;
  //  使用JBHT数据、图层映射关系、NJBDX字段信息创建NJBDX数据集，即创建图层
  JBHT_Create_NJBDX_all_layers_info(
    JBHT_single_frame_data_all_layers_info_entity,
    JBHT_Layers_Mapping_NJBDX_Layers_Json_entity,
    JBHT_Layers_Fields_Info_Json_entity,
    NJBDX_Layers_Fields_Info_Json_entity,
    str_single_output_data_path,
    NJBDX_single_frame_data_all_layers_info_entity,
    single_frame_data_logger);
  //  检查数据集中的图层是否为空
  if (!JBHT_Check_NJBDX_all_layers_info(NJBDX_single_frame_data_all_layers_info_entity))
  {
    single_frame_data_logger->error("函数[{}]：创建的NJBDX分幅数据{}中的有效矢量图层为空。", __FUNCTION__, str_single_output_data_path);
    //  需要将两个数据集关闭以释放内存资源
    JBHT_Close_single_frame_data_all_layers_info(JBHT_single_frame_data_all_layers_info_entity);
    JBHT_Close_NJBDX_all_layers_info(NJBDX_single_frame_data_all_layers_info_entity);
    single_frame_data_logger->info("*****************************************结束处理分幅数据：{}*****************************************", single_frame_data_path);
    return -9;
  }

#pragma endregion

#pragma region "第五步：根据JBHT数据集信息和NJBDX数据集信息、分类编码配置信息进行字段属性映射"
  JBHT_Mapping_NJBDX_Fields(
    JBHT_single_frame_data_all_layers_info_entity,
    NJBDX_single_frame_data_all_layers_info_entity,
    JBHT_Layers_Fields_Info_Json_entity,
    NJBDX_Layers_Fields_Info_Json_entity,
    JBHT_Layers_Mapping_NJBDX_Layers_Json_entity,
    JBHT_Classification_Code_Conditional_Mapping_Lists_Json_entity,
    JBHT_Other_Fields_Mapping_NJBDX_Other_Fields_Json_entity,
    single_frame_data_logger);
#pragma endregion

#pragma region "第六步：释放JBHT分幅数据、NJBDX分幅数据中创建的内存资源"
  //  需要将两个数据集关闭以释放内存资源
  JBHT_Close_single_frame_data_all_layers_info(JBHT_single_frame_data_all_layers_info_entity);
  JBHT_Close_NJBDX_all_layers_info(NJBDX_single_frame_data_all_layers_info_entity);
  single_frame_data_logger->info("*****************************************结束处理分幅数据：{}*****************************************", single_frame_data_path);
  single_frame_data_logger->info("\n\n");

  //  使用 spdlog::shutdown() 来关闭所有日志器
  spdlog::shutdown();
#pragma endregion

  return 0;
}





#pragma region "JBHT2NJBDX_Single_Frame_Data中第五步对应函数"

// -----------------------------------------------------------------------------
//  主要实现函数：将 JBHT 数据源中的要素按分类编码映射到 NJBDX 数据源中
// -----------------------------------------------------------------------------
void qgs_JBHT_NJBDX_semantic_fusion::JBHT_Mapping_NJBDX_Fields(
  const JBHT_single_frame_data_all_layers_info_t& JBHT_single_frame_data_all_layers_info_entity,
  const JBHT_NJBDX_single_frame_data_all_layers_info_t& NJBDX_single_frame_data_all_layers_info_entity,
  const JBHT_Layers_Fields_Info_Json_t& JBHT_Layers_Fields_Info_Json_entity,
  const JBHT_NJBDX_Layers_Fields_Info_Json_t& NJBDX_Layers_Fields_Info_Json_entity,
  const JBHT_Layers_Mapping_NJBDX_Layers_Json_t& JBHT_Layers_Mapping_NJBDX_Layers_Json_entity,
  const JBHT_Classification_Code_Conditional_Mapping_Lists_Json_t& JBHT_Classification_Code_Conditional_Mapping_Lists_Json_entity,
  const JBHT_Other_Fields_Mapping_NJBDX_Other_Fields_Json_t& JBHT_Other_Fields_Mapping_NJBDX_Other_Fields_Json_entity,
  std::shared_ptr<spdlog::logger> single_frame_data_logger)
{
  single_frame_data_logger->info("********函数[{}]日志开始--->进行 JBHT -> NJBDX 字段属性值映射********", __FUNCTION__);

  //  循环处理 JBHT 图层
  for (const auto& JBHT_single_layer : JBHT_single_frame_data_all_layers_info_entity.vJBHT_single_frame_data_single_layer_info)
  {
    //  日志中提示当前正在处理的JBHT图层
    single_frame_data_logger->info("函数[{}]：开始处理 JBHT 图层：{}", __FUNCTION__, JBHT_single_layer.layer_name);

#pragma region "1 在 JBHT_Layers_Mapping_NJBDX_Layers_Json_t 中找出当前JBHT图层对应的映射(一对多)"

    //  在 JBHT_Layers_Mapping_NJBDX_Layers_Json_t 中找出当前JBHT图层对应的映射(一对多)
    const auto& allMappings = JBHT_Layers_Mapping_NJBDX_Layers_Json_entity.vJBHT_layers_mapping_NJBDX_layers;
    //  使用 std::find_if 查找匹配的映射
    auto itFound = std::find_if(allMappings.begin(), allMappings.end(),
      [&JBHT_single_layer, JBHT_Layers_Fields_Info_Json_entity, this, single_frame_data_logger](const JBHT_layers_mapping_NJBDX_layers_t& item) -> bool
      {
        //  解析当前图层的名称（例如D）
        std::string parsedName = this->JBHT_Extract_LayerName(
          JBHT_single_layer.layer_name,
          JBHT_Layers_Fields_Info_Json_entity,
          single_frame_data_logger);

        //  如果解析失败，跳过此元素
        if (parsedName.empty())
        {
          single_frame_data_logger->info("函数[{}]：当前 JBHT 图层{}名称类型解析失败。", __FUNCTION__, JBHT_single_layer.layer_name);
          return false;
        }

        //  比较解析后的名称与映射中的名称
        bool nameMatches = (item.JBHT_Layer.JBHT_layer_english_name == parsedName);

        //  比较几何类型
        bool geometryMatches = (item.JBHT_Layer.JBHT_layer_type == JBHT_single_layer.layer_geo_type);

        //  返回两个条件都满足的结果
        return nameMatches && geometryMatches;
      }
    );
    //  如果在图层映射表中没有找到映射关系则需要将情况写入日志中
    if (itFound == allMappings.end())
    {
      single_frame_data_logger->warn("函数[{}]：无法在JBHT_Layers_Mapping_NJBDX_Layers.json中找到与图层 [{}] 对应的映射关系，跳过当前图层的处理。", __FUNCTION__, JBHT_single_layer.layer_name);
      continue;
    }

    //  在上一步中找到了当前JBHT图层对应映射的NJBDX图层，获取JBHT当前 OGRLayer* 图层指针
    OGRLayer* poJBHTLayer = JBHT_single_layer.polayer;
    //  判断JBHT图层指针是否有效
    if (!poJBHTLayer)
    {
      single_frame_data_logger->warn("函数[{}]：JBHT 图层 [{}] 的 OGRLayer 指针为空，跳过当前图层的处理。", __FUNCTION__, JBHT_single_layer.layer_name);
      continue;
    }
#pragma endregion

#pragma region "2 遍历分类编码条件映射表"

    //  遍历分类编码条件映射表
    for (const auto& codeMapping : JBHT_Classification_Code_Conditional_Mapping_Lists_Json_entity.vJBHT_Classification_Code_Conditional_Mapping_Lists)
    {
#pragma region "2.1 分类编码条件映射表项必要检查"
      //  判断当前‘分类编码条件映射表项’是否需要映射
      if (codeMapping.JBHT_Classification_Code_Mapping_Condition_Flag != "yes")
      {
        single_frame_data_logger->info("函数[{}]：当前'分类编码条件映射表项'中的'映射条件标志'不是'yes'。具体的'分类编码条件映射表项'如下所示：", __FUNCTION__);
        single_frame_data_logger->info("\"Note\":\"{}\"", codeMapping.Note);
        single_frame_data_logger->info("\"JBHT_Classification_Code_Mapping_Condition\":\"{}\"", codeMapping.JBHT_Classification_Code_Mapping_Condition);
        single_frame_data_logger->info("\"JBHT_Classification_Code_Mapping_Condition_Flag\":\"{}\"", codeMapping.JBHT_Classification_Code_Mapping_Condition_Flag);
        single_frame_data_logger->info("\"NJBDX_Classification_Code_Mapping_Condition\":\"{}\"", codeMapping.NJBDX_Classification_Code_Mapping_Condition);
        //  继续处理下一个'分类编码条件映射表项'
        continue;
      }
      //  TODO:检查表达式合法性
      //if (!is_valid_qgis_expression(codeMapping.JBHT_Classification_Code_Mapping_Condition))
      //{
      //  single_frame_data_logger->info("函数[{}]：当前'分类编码条件映射表项'中的'JBHT_Classification_Code_Mapping_Condition'无效。具体的'分类编码条件映射表项'如下所示：", __FUNCTION__);
      //  single_frame_data_logger->info("\"Note\":\"{}\"", codeMapping.Note);
      //  single_frame_data_logger->info("\"JBHT_Classification_Code_Mapping_Condition\":\"{}\"", codeMapping.JBHT_Classification_Code_Mapping_Condition);
      //  single_frame_data_logger->info("\"JBHT_Classification_Code_Mapping_Condition_Flag\":\"{}\"", codeMapping.JBHT_Classification_Code_Mapping_Condition_Flag);
      //  single_frame_data_logger->info("\"NJBDX_Classification_Code_Mapping_Condition\":\"{}\"", codeMapping.NJBDX_Classification_Code_Mapping_Condition);
      //  //  继续处理下一个'分类编码条件映射表项'
      //  continue;

      //}
      //if (!is_valid_qgis_expression(codeMapping.NJBDX_Classification_Code_Mapping_Condition))
      //{
      //  single_frame_data_logger->info("函数[{}]：当前'分类编码条件映射表项'中的'NJBDX_Classification_Code_Mapping_Condition'无效。具体的'分类编码条件映射表项'如下所示：", __FUNCTION__);
      //  single_frame_data_logger->info("\"Note\":\"{}\"", codeMapping.Note);
      //  single_frame_data_logger->info("\"JBHT_Classification_Code_Mapping_Condition\":\"{}\"", codeMapping.JBHT_Classification_Code_Mapping_Condition);
      //  single_frame_data_logger->info("\"JBHT_Classification_Code_Mapping_Condition_Flag\":\"{}\"", codeMapping.JBHT_Classification_Code_Mapping_Condition_Flag);
      //  single_frame_data_logger->info("\"NJBDX_Classification_Code_Mapping_Condition\":\"{}\"", codeMapping.NJBDX_Classification_Code_Mapping_Condition);
      //  //  继续处理下一个'分类编码条件映射表项'
      //  continue;
      //}
#pragma endregion

#pragma region "2.2 根据 JBHT_Classification_Code_Mapping_Condition 对 JBHT 要素进行筛选"

      //  根据 JBHT_Classification_Code_Mapping_Condition 对 JBHT 要素进行筛选，例如可能为："\"CODE\"=140403 AND \"TYPE\"!='栈道'"
      const std::string ogrAttributeFilter = codeMapping.JBHT_Classification_Code_Mapping_Condition;
      //  动态抽取过滤条件中所有字段名称
      std::vector<std::string> fieldNames = extractFieldNames(ogrAttributeFilter);

      //  检查图层定义中是否包含所有过滤条件中引用的字段
      bool allFieldsExist = true;
      OGRFeatureDefn* poJBHTDefn = poJBHTLayer->GetLayerDefn();
      for (const auto& fieldName : fieldNames)
      {
        if (poJBHTDefn->GetFieldIndex(fieldName.c_str()) == -1)
        {
          single_frame_data_logger->warn("函数[{}]：图层 [{}] 中不存在字段 [{}]，过滤条件 [{}] 将不会生效。",
            __FUNCTION__, JBHT_single_layer.layer_name, fieldName, ogrAttributeFilter);
          allFieldsExist = false;
          break;
        }
      }

      //  如果所有字段都存在，则设置属性过滤器；
      if (allFieldsExist)
      {
        if (poJBHTLayer->SetAttributeFilter(ogrAttributeFilter.c_str()) != OGRERR_NONE)
        {
          single_frame_data_logger->error("函数[{}]：设置属性过滤器 [{}] 失败。",
            __FUNCTION__, ogrAttributeFilter);
          continue;
        }
      }
      else
      {
        //  所有字段中的部分字段不存在，不设置属性过滤器，并且对要素不进行处理，直接跳过。
        poJBHTLayer->SetAttributeFilter(nullptr);
        continue;
      }
      poJBHTLayer->ResetReading();

      // 后续对符合过滤条件的要素进行处理
      OGRFeature* poFeature = nullptr;
      while ((poFeature = poJBHTLayer->GetNextFeature()) != nullptr)
      {
        //  先计算 NJBDX_Classification_Code_Mapping_Condition 的结果，例如 "11010202"，然后取其前两位 "11" 来决定映射到哪个 NJBDX 图层
        std::string classificationCodeResult = JBHT_extractClassificationCode(codeMapping.NJBDX_Classification_Code_Mapping_Condition);

        //  取前两位(示例：若得到 "11010202" -> "11")，根据需求可截取其他子串或使用正则等
        std::string targetLayerNumericalIdentification = "";
        std::string targetLayerEnglishName = "";
        if (classificationCodeResult.size() >= 2)
        {
          targetLayerNumericalIdentification = classificationCodeResult.substr(0, 2);  // 提取前两位
        }
        else
        {
          //  若长度不够则跳过
          single_frame_data_logger->warn("函数[{}]：无法从 [{}] 提取有效的图层标识，跳过此要素。", __FUNCTION__, classificationCodeResult);
          OGRFeature::DestroyFeature(poFeature);
          continue;
        }

        //  这里需要将图层标识号（例如11、12、13等等）同具体的英文名称映射从而获取目标图层的英文名称
        for (auto& NJBDX_current_layer : NJBDX_Layers_Fields_Info_Json_entity.vNJBDX_Layers_Fields)
        {
          if (NJBDX_current_layer.NJBDX_Layer_Numerical_Identification == targetLayerNumericalIdentification)
          {
            targetLayerEnglishName = NJBDX_current_layer.NJBDX_Layer_English_Name;
            break;
          }
        }
        if (targetLayerEnglishName == "")
        {
          //  说明没有找到对应的英文名称
          single_frame_data_logger->warn("函数[{}]：无法从 [{}] 提取有效的图层英文名称，跳过此要素。", __FUNCTION__, classificationCodeResult);
          OGRFeature::DestroyFeature(poFeature);
          continue;
        }

        //  找到目标 NJBDX 图层后，获取其 OGRLayer*
        OGRLayer* poNJBDXLayer = nullptr;
        for (auto& nLayerInfo : NJBDX_single_frame_data_all_layers_info_entity.vNJBDX_single_frame_data_single_layer_info)
        {
          
          
          //  这里需要根据几何类型来拼接图层名称
          const std::string NJBDXLayerName = targetLayerEnglishName + "_" + JBHT_OGRGeometryType2String(poJBHTLayer->GetGeomType());
          //  比较解析后的名称与映射中的名称
          bool nameMatches = (nLayerInfo.layer_name == NJBDXLayerName);

          //  比较几何类型（NJBDX图层的几何类型应该同JBHT图层的几何类型是相同的，不应该存在类型不同的情况）
          bool geometryMatches = (nLayerInfo.layer_geo_type == poJBHTLayer->GetGeomType());

          //  如果图层名称、图层几何类型两个条件都满足，那么当前的NJBDX图层即为需要的图层 
          if (nameMatches && geometryMatches)
          {
            poNJBDXLayer = nLayerInfo.polayer;
            break;
          }
        }
        if (!poNJBDXLayer)
        {
          single_frame_data_logger->info("函数[{}]：在 NJBDX 数据源中未找到图层 [{}]，可能不需要为此图层写入要素。", __FUNCTION__, targetLayerEnglishName);
          OGRFeature::DestroyFeature(poFeature);
          continue;
        }

        //  获取 NJBDX 图层的字段定义
        OGRFeatureDefn* poNJBDXDefn = poNJBDXLayer->GetLayerDefn();
        if (!poNJBDXDefn)
        {
          single_frame_data_logger->error("函数[{}]：无法获取 NJBDX 图层 [{}] 的字段定义，跳过写入。", __FUNCTION__, targetLayerEnglishName);
          OGRFeature::DestroyFeature(poFeature);
          //  继续处理下一个要素
          continue;
        }

        //  创建新要素并复制几何
        OGRFeature* poNewNjbdxFeature = OGRFeature::CreateFeature(poNJBDXDefn);
        if (!poNewNjbdxFeature)
        {
          single_frame_data_logger->error("函数[{}]：图层 [{}]中创建 NJBDX 新要素失败，跳过写入。", __FUNCTION__, targetLayerEnglishName);
          OGRFeature::DestroyFeature(poFeature);
          //  继续处理下一个要素
          continue;
        }
        //  将JBHT当前图层要素的几何定义赋值到新创建的NJBDX要素中
        JBHT_copy_geometry_from_source_to_target(poFeature, poNewNjbdxFeature, single_frame_data_logger);



        //  日志说明现在开始处理JBHT数据源中当前图层的‘分类编码’字段属性值映射
        single_frame_data_logger->info("\n-----------------------------------第一步----------------------------------->");
        single_frame_data_logger->info("函数[{}]：第一步--->开始处理 JBHT 图层：{} 中要素ID为 {} 的'分类编码'字段属性值映射。", __FUNCTION__, JBHT_single_layer.layer_name, poFeature->GetFID() + 1);

        //  写入分类编码字段（例如 NJBDX 图层中专门有 "CODE" 字段，即分类编码字段）
        JBHT_mapping_classification_code_field(poNewNjbdxFeature, "CODE", classificationCodeResult);

        //  日志说明现在结束处理JBHT数据源中当前图层的‘分类编码’字段属性值映射
        single_frame_data_logger->info("函数[{}]：第一步--->结束处理 JBHT 图层：{} 中要素ID为 {} 的'分类编码'字段属性值映射。", __FUNCTION__, JBHT_single_layer.layer_name, poFeature->GetFID() + 1);
        single_frame_data_logger->info("-----------------------------------第一步----------------------------------->\n");





        //  日志说明现在开始处理JBHT数据源中当前图层的‘其他’字段属性值映射
        single_frame_data_logger->info("\n-----------------------------------第二步----------------------------------->");
        single_frame_data_logger->info("函数[{}]：第二步--->开始处理 JBHT 图层：{} 中要素ID为 {} 的'其他'字段属性值映射。", __FUNCTION__, JBHT_single_layer.layer_name, poFeature->GetFID() + 1);

        //  获取JBHT_Classification_Code_Conditional_Mapping_Lists_Json_entity对应NJBDX的特定图层
        JBHT_Layers_Other_Fields_Mapping_t JBHT_Layers_Other_Fields_Mapping_entity;
        for (int i = 0; i < JBHT_Other_Fields_Mapping_NJBDX_Other_Fields_Json_entity.vJBHT_Layers_Other_Fields_Mapping.size(); i++)
        {
          //  这里的图层标识符可以是11、12、13等等
          if (JBHT_Other_Fields_Mapping_NJBDX_Other_Fields_Json_entity.vJBHT_Layers_Other_Fields_Mapping[i].NJBDX_Layer_English_Name == targetLayerEnglishName)
          {
            JBHT_Layers_Other_Fields_Mapping_entity = JBHT_Other_Fields_Mapping_NJBDX_Other_Fields_Json_entity.vJBHT_Layers_Other_Fields_Mapping[i];
          }
        }
        //  映射JBHT图层的其他字段属性
        JBHT_mapping_other_fields(
          poFeature,
          poNewNjbdxFeature,
          JBHT_Layers_Other_Fields_Mapping_entity,
          single_frame_data_logger);

        //  日志说明现在结束处理JBHT数据源中当前图层的‘其他’字段属性值映射
        single_frame_data_logger->info("函数[{}]：第二步--->结束处理 JBHT 图层：{} 中要素ID为{} 的'其他'字段属性值映射。", __FUNCTION__, JBHT_single_layer.layer_name, poFeature->GetFID() + 1);
        single_frame_data_logger->info("-----------------------------------第二步----------------------------------->\n");



        //  写入要素到目标图层
        if (poNJBDXLayer->CreateFeature(poNewNjbdxFeature) != OGRERR_NONE)
        {
          single_frame_data_logger->error("函数[{}]：向 NJBDX 图层 [{}] 写入要素失败。", __FUNCTION__, targetLayerEnglishName);
        }

        OGRFeature::DestroyFeature(poNewNjbdxFeature);
        OGRFeature::DestroyFeature(poFeature);
      } // end while

      //  重置过滤器
      poJBHTLayer->SetAttributeFilter(nullptr);
#pragma endregion

    } // end for codeMapping
#pragma endregion

    //  日志中提示当前正在处理的JBHT图层
    single_frame_data_logger->info("函数[{}]：结束处理 JBHT 图层：{}", __FUNCTION__, JBHT_single_layer.layer_name);
  } // end for JBHT_single_layer

  single_frame_data_logger->info("********函数[{}]日志结束--->完成 JBHT -> NJBDX 字段属性值映射********", __FUNCTION__);
}

/**
 * 从输入字符串中提取第一个连续的8位数字字符串。
 *
 * @param input 要处理的输入字符串。
 * @return 提取到的8位数字字符串，如果未找到则返回空字符串。
 */
std::string qgs_JBHT_NJBDX_semantic_fusion::JBHT_extractClassificationCode(const std::string& input)
{
  // 定义匹配8位数字的正则表达式
  std::regex pattern("\\b\\d{8}\\b");
  std::smatch match;

  // 在输入字符串中搜索匹配
  if (std::regex_search(input, match, pattern)) {
    return match.str();
  }

  // 如果没有找到匹配，返回空字符串
  return "";
}

/**
 * @brief 执行 QGIS 表达式，将右侧表达式的计算结果写入到 poTargetFeature 的左侧字段中。
 *
 * 主要修改：在构造表达式上下文后，转换 poSourceFeature 为 QgsFeature 并调用
 * context.setFeature(qgsFeature); 解决表达式中对字段 "NAME" 的引用问题。
 */
std::string qgs_JBHT_NJBDX_semantic_fusion::JBHT_execute_single_qgis_expression(
  const std::string& expression,
  OGRFeature* poSourceFeature,
  OGRFeature* poTargetFeature,
  std::shared_ptr<spdlog::logger> logger)
{
  // 1. 参数有效性判断 
  if (!poSourceFeature || !poTargetFeature || expression.empty())
  {
    logger->error("函数[{}]：无效参数(空Feature或空表达式)。", __FUNCTION__);
    return std::string();
  }
  // 2. 找到表达式中的 '='，解析左侧(目标字段)和右侧(QGIS表达式)，示例: NAME_E = CASE WHEN "NAME"= '北京' THEN '北京E' ELSE "NAME" END
  const size_t eqPos = expression.find('=');
  if (eqPos == std::string::npos)
  {
    logger->error("函数[{}]：表达式中缺少 '='，无法执行字段更新。表达式：{}", __FUNCTION__, expression);
    return std::string();
  }

  // 将左边视为目标字段名，右边视为 QGIS 表达式
  std::string leftField = expression.substr(0, eqPos);
  std::string rightExpr = expression.substr(eqPos + 1);

  // 去除左右两边空格
  auto trim = [](std::string& s) {
    s.erase(0, s.find_first_not_of(" \t\r\n"));
    s.erase(s.find_last_not_of(" \t\r\n") + 1);
  };
  trim(leftField);
  trim(rightExpr);

  if (leftField.empty() || rightExpr.empty())
  {
    logger->error("函数[{}]：目标字段或右侧表达式为空。原始表达式：{}", __FUNCTION__, expression);
    return std::string();
  }

  // 3. 构造 QGIS 表达式 (右侧)
  QgsExpression exp(QString::fromStdString(rightExpr));
  if (exp.hasParserError())
  {
    logger->error("函数[{}]：解析表达式失败：{}，错误信息：{}.",
      __FUNCTION__,
      rightExpr,
      exp.parserErrorString().toStdString());
    return std::string();
  }

  // 4. 构造表达式上下文，并将 SourceFeature 的字段加载进去
  QgsExpressionContext context;
  JBHT_fillExpressionContextFromOGRFeature(poSourceFeature, context);

  //  将整个 feature 传入表达式上下文，使表达式中的字段引用（如 "NAME"）能正确解析
  QgsFeature qgsFeature = convertOGRFeatureToQgsFeature(poSourceFeature);
  context.setFeature(qgsFeature);

  // 5. 进行表达式评估
  QVariant result = exp.evaluate(&context);
  if (exp.hasEvalError())
  {
    logger->error("函数[{}]：表达式计算出错：{}，错误信息：{}.",
      __FUNCTION__,
      rightExpr,
      exp.evalErrorString().toStdString());
    return std::string();
  }

  // 6. 将结果写入到 poTargetFeature 的左侧字段 (leftField)
  OGRFeatureDefn* pTargetDefn = poTargetFeature->GetDefnRef();
  if (!pTargetDefn)
  {
    logger->error("函数[{}]：目标要素的字段定义为空，无法写入字段。", __FUNCTION__);
    return std::string();
  }

  int targetFieldIndex = pTargetDefn->GetFieldIndex(leftField.c_str());
  if (targetFieldIndex < 0)
  {
    logger->error("函数[{}]：目标要素无此字段：{}.", __FUNCTION__, leftField);
    return std::string();
  }

  // 根据 result 的类型，选择合适的 OGR SetField 重载
  switch (result.type())
  {
  case QMetaType::Int:
  case QMetaType::LongLong:
  case QMetaType::UInt:
  case QMetaType::ULongLong:
    poTargetFeature->SetField(targetFieldIndex, static_cast<GIntBig>(result.toLongLong()));
    break;
  case QMetaType::Double:
    poTargetFeature->SetField(targetFieldIndex, result.toDouble());
    break;
  case QMetaType::Bool:
    poTargetFeature->SetField(targetFieldIndex, result.toBool() ? 1 : 0);
    break;
  default:
  {
    std::string valStr = result.toString().toStdString();
    poTargetFeature->SetField(targetFieldIndex, valStr.c_str());
  }
  break;
  }

  // 7. 返回计算结果（以字符串形式返回）
  return result.toString().toStdString();
}

std::vector<std::string> qgs_JBHT_NJBDX_semantic_fusion::JBHT_execute_multiple_qgis_expressions(
  const std::vector<std::string>& expressions,
  OGRFeature* poSourceFeature,
  OGRFeature* poTargetFeature,
  std::shared_ptr<spdlog::logger> logger)
{
  std::vector<std::string> results;
  if (!poSourceFeature || !poTargetFeature || expressions.empty())
  {
    logger->error("函数[{}]：无效参数(空Feature或空表达式)。", __FUNCTION__);
    return results;
  }

  // 构造表达式上下文
  QgsExpressionContext context;
  JBHT_fillExpressionContextFromOGRFeature(poSourceFeature, context);
  QgsFeature qgsFeature = convertOGRFeatureToQgsFeature(poSourceFeature);
  context.setFeature(qgsFeature);

  OGRFeatureDefn* pTargetDefn = poTargetFeature->GetDefnRef();
  if (!pTargetDefn)
  {
    logger->error("函数[{}]：目标要素的字段定义为空。", __FUNCTION__);
    return results;
  }

  // 遍历所有表达式
  for (const std::string& expression : expressions)
  {
    // 找到表达式中的 '='，拆分左右部分
    const size_t eqPos = expression.find('=');
    if (eqPos == std::string::npos)
    {
      logger->error("函数[{}]：表达式中缺少 '='，无法执行字段更新。表达式：{}", __FUNCTION__, expression);
      results.push_back("");
      continue;
    }

    std::string leftField = expression.substr(0, eqPos);
    std::string rightExpr = expression.substr(eqPos + 1);

    // 去除左右两侧空格
    auto trim = [](std::string& s) {
      s.erase(0, s.find_first_not_of(" \t\r\n"));
      s.erase(s.find_last_not_of(" \t\r\n") + 1);
    };
    trim(leftField);
    trim(rightExpr);

    if (leftField.empty() || rightExpr.empty())
    {
      logger->error("函数[{}]：目标字段或右侧表达式为空。原始表达式：{}", __FUNCTION__, expression);
      results.push_back("");
      continue;
    }

    // 构造并计算表达式
    QgsExpression exp(QString::fromStdString(rightExpr));
    if (exp.hasParserError())
    {
      logger->error("函数[{}]：解析表达式失败：{}，错误信息：{}.",
        __FUNCTION__, rightExpr, exp.parserErrorString().toStdString());
      results.push_back("");
      continue;
    }

    QVariant result = exp.evaluate(&context);
    if (exp.hasEvalError())
    {
      logger->error("函数[{}]：表达式计算出错：{}，错误信息：{}.",
        __FUNCTION__, rightExpr, exp.evalErrorString().toStdString());
      results.push_back("");
      continue;
    }

    // 找到目标字段在 poTargetFeature 中的索引
    int targetFieldIndex = pTargetDefn->GetFieldIndex(leftField.c_str());
    if (targetFieldIndex < 0)
    {
      logger->error("函数[{}]：目标要素无此字段：{}.", __FUNCTION__, leftField);
      results.push_back("");
      continue;
    }

    // 根据计算结果的类型选择合适的 SetField 重载
    switch (result.type())
    {
    case QMetaType::Int:
    case QMetaType::LongLong:
    case QMetaType::UInt:
    case QMetaType::ULongLong:
      poTargetFeature->SetField(targetFieldIndex, static_cast<GIntBig>(result.toLongLong()));
      break;
    case QMetaType::Double:
      poTargetFeature->SetField(targetFieldIndex, result.toDouble());
      break;
    case QMetaType::Bool:
      poTargetFeature->SetField(targetFieldIndex, result.toBool() ? 1 : 0);
      break;
    default:
      poTargetFeature->SetField(targetFieldIndex, result.toString().toStdString().c_str());
      break;
    }

    // 保存此次表达式计算结果（以字符串形式）
    results.push_back(result.toString().toStdString());
  }
  return results;
}


/**
 * @brief 将 OGRFeature 转换为 QgsFeature，以便在表达式上下文中设置 feature，
 *        使得表达式中对字段名称（如 "NAME"）的引用能正确解析。
 */
QgsFeature qgs_JBHT_NJBDX_semantic_fusion::convertOGRFeatureToQgsFeature(OGRFeature* poSourceFeature)
{
  QgsFeature qgsFeature;
  if (!poSourceFeature)
    return qgsFeature;

  OGRFeatureDefn* poDefn = poSourceFeature->GetDefnRef();
  if (!poDefn)
    return qgsFeature;

  QgsFields fields;
  // 遍历 OGRFeature 的字段定义，构造 QgsFields
  for (int i = 0; i < poDefn->GetFieldCount(); i++)
  {
    OGRFieldDefn* fieldDefn = poDefn->GetFieldDefn(i);
    if (!fieldDefn)
      continue;
    // 根据 OGR 字段类型映射到 QVariant 类型
    QVariant::Type qType = QVariant::String;
    switch (fieldDefn->GetType())
    {
    case OFTInteger:
    case OFTInteger64:
      qType = QVariant::LongLong;
      break;
    case OFTReal:
      qType = QVariant::Double;
      break;
    default:
      qType = QVariant::String;
      break;
    }
    fields.append(QgsField(QString::fromUtf8(fieldDefn->GetNameRef()), qType));
  }
  /*
  Notes:杨小兵-2025-02-12

  1、QgsFeature 字段与属性的分离
    1.1 注意 QGIS 的 API 中，setFields() 默认不会为 feature 初始化属性值（即不会为内部属性数组分配空间），除非显式要求分配默认值。
  2、内部属性数组未初始化
    2.1 由于内部属性数组为空，当 QGIS 表达式引擎（或者其它内部逻辑）调用 feature 的 attribute(index) 方法时，就会发现没有任何属性（大小为 0），从而触发“Attribute index X out of bounds [0;0]”警告。
    2.2 尽管后续你通过 setAttribute() 填充了部分值，但如果内部数组本身没有被预先分配成与字段数一致的大小，每次对属性的访问都会检测到索引越界。
  3、多次访问导致重复警告
    3.1 QGIS 的表达式解析或其它内部代码在多次循环或多次尝试访问 feature 的每个字段时，都可能触发这种警告，因而日志中出现大量重复的“Attribute index ... out of bounds”消息。
  4、为了解决这些警告，可以确保在设置字段后，对 feature 的属性数组进行初始化。常用的做法有：
    4.1 在 setFields 时分配默认值，使用 QGIS API 提供的第二个参数，将默认值分配给属性：qgsFeature.setFields(fields, true);这样，内部属性数组会被初始化成与字段数相同的大小，每个位置赋以默认（空或 null）值。
  */
  qgsFeature.setFields(fields, true);

  // 设置 QgsFeature 的属性值，根据不同字段类型进行精细转换
  for (int i = 0; i < fields.count(); i++)
  {
    if (poSourceFeature->IsFieldSetAndNotNull(i))
    {
      OGRFieldDefn* fieldDefn = poDefn->GetFieldDefn(i);
      if (!fieldDefn)
        continue;

      switch (fieldDefn->GetType())
      {
      case OFTInteger:
      case OFTInteger64:
      {
        // 整数类型转换
        GIntBig intValue = poSourceFeature->GetFieldAsInteger64(i);
        qgsFeature.setAttribute(i, QVariant::fromValue(intValue));
        break;
      }
      case OFTReal:
      {
        // 浮点数类型转换
        double dValue = poSourceFeature->GetFieldAsDouble(i);
        qgsFeature.setAttribute(i, QVariant::fromValue(dValue));
        break;
      }
      case OFTString:
      {
        // 字符串类型转换
        QString strValue = QString::fromUtf8(poSourceFeature->GetFieldAsString(i));
        qgsFeature.setAttribute(i, strValue);
        break;
      }
      case OFTDate:
      case OFTTime:
      case OFTDateTime:
      {
        // 日期/时间类型转换：调用 GetFieldAsDateTime 获取年月日时分秒信息
        int year = 0, month = 0, day = 0, hour = 0, minute = 0, second = 0, tzFlag = 0;
        if (poSourceFeature->GetFieldAsDateTime(i, &year, &month, &day, &hour, &minute, &second, &tzFlag))
        {
          QDate date(year, month, day);
          QTime time(hour, minute, second);
          QDateTime dateTime(date, time);
          qgsFeature.setAttribute(i, dateTime);
        }
        else
        {
          // 若解析失败，则回退为字符串转换
          QString strValue = QString::fromUtf8(poSourceFeature->GetFieldAsString(i));
          qgsFeature.setAttribute(i, strValue);
        }
        break;
      }
      default:
      {
        // 其它类型，采用字符串转换
        QString strValue = QString::fromUtf8(poSourceFeature->GetFieldAsString(i));
        qgsFeature.setAttribute(i, strValue);
        break;
      }
      }
    }
  }
  return qgsFeature;
}

/**
 * @brief 将源要素(来自JBHT)的几何复制到新要素(将写入NJBDX)
 *
 * @param poSourceFeature 源 OGRFeature 指针
 * @param poTargetFeature 目标 OGRFeature 指针
 */
void qgs_JBHT_NJBDX_semantic_fusion::JBHT_copy_geometry_from_source_to_target(
  OGRFeature* poSourceFeature,
  OGRFeature* poTargetFeature,
  std::shared_ptr<spdlog::logger> single_frame_data_logger)
{
  //  检查输入参数的有效性
  if (!poSourceFeature || !poTargetFeature)
  {
    return;
  }
  //  获取源要素的几何引用
  OGRGeometry* poSrcGeometry = poSourceFeature->GetGeometryRef();
  //  如果获取的源要素几何引用是有效的
  if (poSrcGeometry)
  {
    //  克隆几何并赋给目标要素
    OGRGeometry* poClonedGeometry = poSrcGeometry->clone();
    poTargetFeature->SetGeometry(poClonedGeometry);
    // poClonedGeometry 由 poTargetFeature 接管，无需手动 OGRGeometryFactory::destroyGeometry
  }
  else
  {
    //  记录错误信息
    single_frame_data_logger->info("函数[{}]：将JBHT要素的几何信息复制给NJBDX要素出现了错误。", __FUNCTION__);
  }
}

/**
 * @brief 将“分类编码”字段写入到目标要素中
 *
 * @param poTargetFeature 目标要素（将写入 NJBDX）
 * @param targetFieldName 目标字段名（如 "ClassificationCode"）
 * @param classificationCodeExpr 根据表达式计算得到的分类编码值
 */
void qgs_JBHT_NJBDX_semantic_fusion::JBHT_mapping_classification_code_field(
  OGRFeature* poTargetFeature,
  const std::string& targetFieldName,
  const std::string& classificationCodeExpr)
{
  //  检查输入参数的有效性
  if (!poTargetFeature)
  {
    return;
  }

  //  直接将字符串写入目标要素的指定字段，如果有更复杂的类型（如整数类型），应先进行转换，TODO:当前函数实现不完整
  poTargetFeature->SetField(targetFieldName.c_str(), classificationCodeExpr.c_str());
}

/**
 * @brief 将其他字段（非分类编码字段）从JBHT映射到NJBDX
 *
 * @param poSourceFeature 源 OGRFeature（JBHT）
 * @param poTargetFeature 目标 OGRFeature（NJBDX）
 * @param vOtherFieldsMapping 当前图层的“其他字段映射”规则
 * @param single_frame_data_logger 日志记录器
 */
void qgs_JBHT_NJBDX_semantic_fusion::JBHT_mapping_other_fields(
  OGRFeature* poSourceFeature,
  OGRFeature* poTargetFeature,
  const JBHT_Layers_Other_Fields_Mapping_t& JBHT_Layers_Other_Fields_Mapping_entity,
  std::shared_ptr<spdlog::logger> single_frame_data_logger)
{
  //  检查输入参数的有效性，函数调用者可以保证要素指针是有效的
  if (!poSourceFeature || !poTargetFeature)
  {
    return;
  }

  //  遍历当前图层在 “JBHT_Other_Fields_Mapping_NJBDX_Other_Fields.json” 中配置的映射关系
  for (const auto& mappingItem : JBHT_Layers_Other_Fields_Mapping_entity.vOther_Fields_Mapping)
  {
    //  如果 field_mapping_codition_flag != "yes"，说明该字段不需要进行映射
    if (mappingItem.field_mapping_codition_flag != "yes")
    {
      //  继续处理下一个字段映射
      continue;
    }

    ////  TODO:mappingItem.field_mapping_codition 也是 QGIS 表达式，需要先校验并执行
    //if (!is_valid_qgis_expression(mappingItem.field_mapping_codition))
    //{
    //  //  TODO:这里需要记录详细信息，说明整个字段映射条件
    //  single_frame_data_logger->warn(
    //    "函数[{}]：其他字段映射中的表达式无效，跳过映射。字段：{}，表达式：{}",
    //    __FUNCTION__,
    //    mappingItem.JBHT_field_name,
    //    mappingItem.field_mapping_codition);

    //  //  继续处理下一个字段映射
    //  continue;
    //}

    /*
    Notes:杨小兵-2025-02-12

    1、示例
    （1）假设我们有一个矢量要素，其中包含以下字段：
      population（整数，表示人口数量）
      city_name（字符串，表示城市名称）
    一个常见的 QGIS 表达式示例：
      "population" > 10000 AND "city_name" = 'Beijing'
    （2）解释：
      population > 10000 表示人口数量大于 1 万
      city_name = 'Beijing' 表示城市名称为 "Beijing"
      AND 表示逻辑与，只有当这两个条件都满足时，表达式才为 true

    2、示例2
    （1）如果换一个示例用于更新，比如：
      "population" = "population" + 500
    （2）解释：
      将要素的 population 字段更新为 原 population 值加上 500
      这种表达式在 QGIS 里经常用于字段计算器，也可以在 C++ 里通过 QgsExpression 动态求值并写回字段值。
    */
    std::string evalResult = JBHT_execute_single_qgis_expression(
      mappingItem.field_mapping_codition,
      poSourceFeature,
      poTargetFeature,
      single_frame_data_logger);


    // TODO:编写日志
  }
}

/**
 * @brief 从 OGRFeature 中取出字段名与字段值，并加入到 QGIS Expression 上下文 (QgsExpressionContext) 中。
 *
 * 因为 QGIS 3.28 版本中没有 QgsExpressionContext::setVariable()，
 * 所以使用 QgsExpressionContextScope 将每个字段以变量的形式加入上下文，
 * 但注意：表达式中引用变量时需要使用 '@' 前缀。
 *
 * @param poSourceFeature 传入的源要素(OGR)
 * @param context         用于表达式计算的 QGIS 表达式上下文
 */
void qgs_JBHT_NJBDX_semantic_fusion::JBHT_fillExpressionContextFromOGRFeature(
  OGRFeature* poSourceFeature,
  QgsExpressionContext& context)
{
  if (!poSourceFeature)
    return;

  OGRFeatureDefn* poDefn = poSourceFeature->GetDefnRef();
  if (!poDefn)
    return;

  QgsExpressionContextScope* scope = new QgsExpressionContextScope();
  int fieldCount = poDefn->GetFieldCount();
  for (int i = 0; i < fieldCount; ++i)
  {
    OGRFieldDefn* fieldDefn = poDefn->GetFieldDefn(i);
    if (!fieldDefn)
      continue;

    const char* fieldName = fieldDefn->GetNameRef();
    if (!fieldName)
      continue;

    if (!poSourceFeature->IsFieldSetAndNotNull(i))
      continue;

    OGRFieldType fieldType = fieldDefn->GetType();
    QVariant qValue;
    switch (fieldType)
    {
    case OFTInteger:
    case OFTInteger64:
      qValue = QVariant(poSourceFeature->GetFieldAsInteger64(i));
      break;
    case OFTReal:
      qValue = QVariant(poSourceFeature->GetFieldAsDouble(i));
      break;
    case OFTString:
      qValue = QVariant(QString::fromUtf8(poSourceFeature->GetFieldAsString(i)));
      break;
    case OFTDate:
    case OFTTime:
    case OFTDateTime:
      qValue = QVariant(QString::fromUtf8(poSourceFeature->GetFieldAsString(i)));
      break;
    default:
      qValue = QVariant(QString::fromUtf8(poSourceFeature->GetFieldAsString(i)));
      break;
    }
    scope->setVariable(QString(fieldName), qValue);
  }
  context.appendScope(scope);
}

#pragma endregion






//  获取JBHT单个分幅数据集的信息
void qgs_JBHT_NJBDX_semantic_fusion::JBHT_Create_single_frame_data_all_layers_info(
  GDALDataset* poSingleFrameJBHTDataSet,
  JBHT_single_frame_data_all_layers_info_t& JBHT_single_frame_data_all_layers_info_entity,
  std::shared_ptr<spdlog::logger> single_frame_data_logger)
{

  if (!poSingleFrameJBHTDataSet)
  {
    //  数据集指针为空则设置成默认值
    JBHT_single_frame_data_all_layers_info_entity.JBHT_single_frame_data_poDS = NULL;
    single_frame_data_logger->error("函数[{}]：数据集指针为空。", __FUNCTION__);
    return;
  }
  else
  {
    //  设置数据集指针
    JBHT_single_frame_data_all_layers_info_entity.JBHT_single_frame_data_poDS = poSingleFrameJBHTDataSet;
  }

  //  获取并设置数据集路径
  const char* dataset_path = poSingleFrameJBHTDataSet->GetDescription();
  if (!dataset_path)
  {
    //  获取不到则设置成默认值
    JBHT_single_frame_data_all_layers_info_entity.JBHT_single_frame_data_path = "";
    single_frame_data_logger->error("函数[{}]：获取数据集路径失败。", __FUNCTION__);
    return;
  }
  else
  {
    //  获取得到则赋值
    JBHT_single_frame_data_all_layers_info_entity.JBHT_single_frame_data_path = dataset_path;
  }

  //  获取图层数量
  int layer_count = poSingleFrameJBHTDataSet->GetLayerCount();

  //  遍历每个图层
  for (int i = 0; i < layer_count; ++i)
  {
    //  获取图层指针
    OGRLayer* layer = poSingleFrameJBHTDataSet->GetLayer(i);
    if (!layer)
    {
      single_frame_data_logger->error("函数[{}]：获取第{}个图层失败，已经跳过该图层的处理。", __FUNCTION__, i);
      //  跳过无效图层
      continue; 
    }
      
    //  创建单个图层信息结构体变量
    JBHT_single_frame_data_single_layer_info_t layer_info;
    //  获取并设置图层名称
    const char* layer_name = layer->GetName();
    if (!layer_name)
    {
      single_frame_data_logger->error("函数[{}]：获取第{}个图层的名称失败，已经跳过该图层的处理。", __FUNCTION__, i);
      layer_info.layer_name = "";
      continue;
    }
    else
    {
      layer_info.layer_name = layer_name;
    }
    

    //  获取并设置几何类型
    OGRwkbGeometryType geom_type = layer->GetGeomType();
    layer_info.layer_geo_type = geom_type;

    //  赋值图层指针到自定义结构体中
    layer_info.polayer = layer;

    //  获取空间参考
    OGRSpatialReference* poSRS = layer->GetSpatialRef();
    if (poSRS)
    {
      layer_info.poSRS = poSRS;
    }
    else
    {
      single_frame_data_logger->error("函数[{}]：获取第{}个图层的空间参考失败，已经跳过该图层的处理。", __FUNCTION__, i);
      layer_info.poSRS = nullptr;
      continue;
    }

    //  将图层信息添加到向量中
    JBHT_single_frame_data_all_layers_info_entity.vJBHT_single_frame_data_single_layer_info.push_back(layer_info);
  }
}

//  检查JBHT数据集中的有效图层是否为空
bool qgs_JBHT_NJBDX_semantic_fusion::JBHT_Check_single_frame_data_all_layers_info(
  const JBHT_single_frame_data_all_layers_info_t& JBHT_single_frame_data_all_layers_info_entity,
  std::shared_ptr<spdlog::logger> single_frame_data_logger)
{
  //  TODO：添加更为详细的检查
  if (JBHT_single_frame_data_all_layers_info_entity.vJBHT_single_frame_data_single_layer_info.size() == 0)
  {
    return false;
  }
  return true;
}

//  释放JBHT单个分幅数据集资源
void qgs_JBHT_NJBDX_semantic_fusion::JBHT_Close_single_frame_data_all_layers_info(
  JBHT_single_frame_data_all_layers_info_t& JBHT_single_frame_data_all_layers_info_entity)
{
  if (JBHT_single_frame_data_all_layers_info_entity.JBHT_single_frame_data_poDS)
  {
    GDALClose(JBHT_single_frame_data_all_layers_info_entity.JBHT_single_frame_data_poDS);
  }
  return;
}





//  创建NJBDX单个分幅数据集的信息
bool qgs_JBHT_NJBDX_semantic_fusion::JBHT_Create_NJBDX_all_layers_info(
  const JBHT_single_frame_data_all_layers_info_t& JBHT_single_frame_data_all_layers_info_entity,
  const JBHT_Layers_Mapping_NJBDX_Layers_Json_t& JBHT_Layers_Mapping_NJBDX_Layers_Json_entity,
  const JBHT_Layers_Fields_Info_Json_t& JBHT_Layers_Fields_Info_Json_entity,
  const JBHT_NJBDX_Layers_Fields_Info_Json_t& NJBDX_Layers_Fields_Info_Json_entity,
  const std::string& NJBDX_str_output_data_path,
  JBHT_NJBDX_single_frame_data_all_layers_info_t& NJBDX_single_frame_data_all_layers_info_entity,
  std::shared_ptr<spdlog::logger> single_frame_data_logger)
{
  //  日志：开始
  single_frame_data_logger->info("********函数[{}]：日志开始--->在目录{}中创建 NJBDX Shapefile 图层********", __FUNCTION__, NJBDX_str_output_data_path);

  NJBDX_single_frame_data_all_layers_info_entity.NJBDX_single_frame_data_path = NJBDX_str_output_data_path;

#pragma region "1 设置GDAL并且获取驱动器"
  //  这告诉 GDAL 文件名使用 UTF-8 编码
  CPLSetConfigOption("GDAL_FILENAME_IS_UTF8", "YES");
  //  自动检测 DBF 编码
  CPLSetConfigOption("SHAPE_ENCODING", "");
  //  注册所有 GDAL 驱动
  GDALAllRegister();
  const char* pszShpDriverName = "ESRI Shapefile";
  GDALDriver* poDriver = GetGDALDriverManager()->GetDriverByName(pszShpDriverName);
  if (poDriver == NULL)
  {
    single_frame_data_logger->error("函数[{}]：获取ESRI Shapefile矢量驱动器失败。", __FUNCTION__);
    return false;
  }
#pragma endregion

#pragma region "2 根据JBHT图层信息遍历图层信息"
  //  用于存储已创建的 “NJBDX 图层英文名 -> GDALDataset*” 以避免重复创建
  std::map<std::string, GDALDataset*> createdDatasets;

  //  遍历所有 JBHT 图层信息
  for (const auto& JBHTLayerInfo : JBHT_single_frame_data_all_layers_info_entity.vJBHT_single_frame_data_single_layer_info)
  {
    //  获取得到当前JBHT单个图层的名称例如（DN09490622_D_line）
    const std::string& JBHTLayerName = JBHTLayerInfo.layer_name;
    //  获取得到当前JBHT单个图层的几何类型
    OGRwkbGeometryType JBHT_layer_geo_type = JBHTLayerInfo.layer_geo_type;

#pragma region "2.1 在JBHT_Layers_Mapping_NJBDX_Layers.json中找到对应的映射项"
    //  2.1 在映射表中查找对应的 NJBDX 图层集合
    JBHT_layers_mapping_NJBDX_layers_t MappingItem;
    //  提取JBHT图层名称(DN09490622_D_line--->D，根据不同的数据源将会有不同的抽取规则)
    std::string JBHT_extracted_layername = JBHT_Extract_LayerName(JBHTLayerName, JBHT_Layers_Fields_Info_Json_entity, single_frame_data_logger);

    //  循环遍历所有 JBHT_mapping_NJBDX 图层信息项
    for (auto& mapItem : JBHT_Layers_Mapping_NJBDX_Layers_Json_entity.vJBHT_layers_mapping_NJBDX_layers)
    {
      //  每次迭代都重新初始化匹配标志
      bool layer_name_match_flag = false;
      bool layer_geo_type_match_flag = false;

      //  使用图层的英文名称判断是否匹配
      if (mapItem.JBHT_Layer.JBHT_layer_english_name == JBHT_extracted_layername)
      {
        layer_name_match_flag = true;
      }
      //  判断图层的几何类型是否匹配
      if (mapItem.JBHT_Layer.JBHT_layer_type == JBHT_layer_geo_type)
      {
        layer_geo_type_match_flag = true;
      }

      //  如果图层的名称和几何类型都匹配，则获取到正确的映射信息
      if (layer_name_match_flag && layer_geo_type_match_flag)
      {
        MappingItem = mapItem;
        break;
      }
    }
    //  如果没有获取到对应的图层映射信息，说明配置文件填写不完整
    if (MappingItem.vNJBDX_Mapping_Layers.size() == 0)
    {
      //  未在映射表中找到对应的 NJBDX 图层
      single_frame_data_logger->info("函数[{}]：JBHT 图层[{}]在映射表中找到了空的对应 NJBDX 图层，已跳过该图层的处理", __FUNCTION__, JBHTLayerName);
      continue;
    }
#pragma endregion

#pragma region "2.2 根据JBHT图层的映射关系创建新的NJBDX图层"
    //  循环遍历该 JBHT 图层映射到的多个 NJBDX 图层
    for (auto& singleNJBDXLayerMapping : MappingItem.vNJBDX_Mapping_Layers)
    {
      //  获取当前NJBDX图层信息中的英文名称（TODO:这里需要进行修改，从11、12等修改为具体的英文名称）
      const std::string& NJBDXLayerEnglishName = singleNJBDXLayerMapping.NJBDX_layer_english_name;
      //  将英文名称和图层几何类型结合起来（TODO:这里需要进行修改，从11_Point等修改为英文名称_Point）
      const std::string& NJBDXLayerEnglishName_GeoType = NJBDXLayerEnglishName + "_" + JBHT_OGRGeometryType2String(singleNJBDXLayerMapping.NJBDX_layer_type);

      //  判断是否已经创建过同名的 NJBDX 图层（Shapefile）
      GDALDataset* poExistingDataset = nullptr;
      auto itFound = createdDatasets.find(NJBDXLayerEnglishName_GeoType);
      if (itFound != createdDatasets.end())
      {
        poExistingDataset = itFound->second;
      }
      //  如果还没创建，执行创建
      if (!poExistingDataset)
      {
        //  拼接输出 Shapefile 路径
        std::string shpFilePath = NJBDX_str_output_data_path + "/" + NJBDXLayerEnglishName_GeoType + ".shp";

        //  如果已存在同名文件，先删除（可按需决定是否覆盖）
        if (CPLCheckForFile((char*)shpFilePath.c_str(), nullptr))
        {
          if (poDriver->Delete(shpFilePath.c_str()) != CE_None)
          {
            single_frame_data_logger->info("函数[{}]：删除已存在Shapefile文件失败：{}", __FUNCTION__, shpFilePath);
            //  继续处理下一个映射图层
            continue;
          }
          single_frame_data_logger->info("函数[{}]：覆盖删除旧Shapefile文件：{}", __FUNCTION__, shpFilePath);
        }

        // 设置创建选项，指定 CPG 选项为 UTF-8
        char** papszOptions = nullptr;
        papszOptions = CSLSetNameValue(papszOptions, "CPG", "UTF-8");

        //  创建新的 Shapefile 数据集
        GDALDataset* poNewDS = poDriver->Create(shpFilePath.c_str(), 0, 0, 0, GDT_Unknown, papszOptions);
        if (!poNewDS)
        {
          single_frame_data_logger->error("函数[{}]：创建Shapefile文件失败：{}", __FUNCTION__, shpFilePath);
          //  继续处理下一个映射图层
          continue;
        }

        //  设置空间参考（沿用JBHT图层的 poSRS）
        OGRSpatialReference* poRef = nullptr;
        if (JBHTLayerInfo.poSRS)
        {
          poRef = JBHTLayerInfo.poSRS->Clone();
        }

        //  在该 Shapefile 数据集中创建图层
        OGRLayer* poNewLayer = poNewDS->CreateLayer(NJBDXLayerEnglishName_GeoType.c_str(), poRef, JBHT_layer_geo_type, nullptr);
        if (!poNewLayer)
        {
          single_frame_data_logger->error("函数[{}]：在 {} 创建图层 [{}] 失败！", __FUNCTION__, shpFilePath, NJBDXLayerEnglishName_GeoType);
          //  之后释放创建出来的空间引用
          if (poRef) poRef->Release();
          GDALClose(poNewDS);
          //  继续处理下一个映射图层
          continue;
        }
        //  poRef 在 CreateLayer 之后释放
        if (poRef)
        {
          poRef->Release();
          poRef = nullptr;
        }

        //  NJBDX_Layers_Fields_Info_Json_entity 中，根据 NJBDXLayerEnglishName_GeoType 匹配字段配置，并创建字段
        bool bFindFieldCfg = false;
        //  创建NJBDX中当前图层的字段信息
        for (auto& layersFields : NJBDX_Layers_Fields_Info_Json_entity.vNJBDX_Layers_Fields)
        {
          //  获取得到想要的NJBDX的图层信息
          if (layersFields.NJBDX_Layer_English_Name == NJBDXLayerEnglishName)
          {
            bFindFieldCfg = true;
            //  遍历字段配置，逐一创建字段
            for (auto& fieldDef : layersFields.vFields)
            {
              OGRFieldDefn oFieldDefn(fieldDef.english_field_name.c_str(), fieldDef.field_type);
              oFieldDefn.SetWidth(fieldDef.field_length);
              oFieldDefn.SetPrecision(fieldDef.field_precision);

              if (poNewLayer->CreateField(&oFieldDefn) != OGRERR_NONE)
              {
                single_frame_data_logger->error("函数{}：图层 [{}] 创建字段 [{}] 失败！",
                  __FUNCTION__, NJBDXLayerEnglishName, fieldDef.english_field_name);
              }
              else
              {
                single_frame_data_logger->info("函数{}：图层 [{}] 成功创建字段 [{}]",
                  __FUNCTION__, NJBDXLayerEnglishName, fieldDef.english_field_name);
              }
            }
            //  找到匹配就不再往下搜
            break;
          }
        }
        //  如果在配置文件中没有找到对应图层的字段信息，则给出提示
        if (!bFindFieldCfg)
        {
          single_frame_data_logger->warn("函数[{}]：NJBDX图层 [{}] 在字段配置表中无匹配项，跳过字段创建。", __FUNCTION__, NJBDXLayerEnglishName);
        }


        //  手动创建 .cpg 文件，确保写入编码信息（处理中文路径问题）,将 NJBDX_str_output_data_path 转换为 QString
        QString qOutputPath = QString::fromStdString(NJBDX_str_output_data_path);
        //  将 NJBDXLayerEnglishName_GeoType 转换为 QString，并拼接 .cpg 后缀
        QString qCpgFilePath = qOutputPath + "/" + QString::fromStdString(NJBDXLayerEnglishName_GeoType) + ".cpg";
        //  转换为本地8位编码，解决 Windows 下中文路径问题
        QByteArray baCpgFilePath = qCpgFilePath.toLocal8Bit();

        std::ofstream cpgFile(baCpgFilePath.constData());
        if (!cpgFile.is_open())
        {
          single_frame_data_logger->error("函数[{}]：无法创建 .cpg 文件：{}", __FUNCTION__, qCpgFilePath.toStdString());
        }
        else
        {
          cpgFile << "UTF-8";  // 写入编码信息
          cpgFile.close();
          single_frame_data_logger->info("函数[{}]：成功创建 .cpg 文件：{}", __FUNCTION__, qCpgFilePath.toStdString());
        }


        //  记录到 map，避免重复创建
        createdDatasets[NJBDXLayerEnglishName_GeoType] = poNewDS;

        //  在输出结构 NJBDX_single_frame_data_all_layers_info_entity 中记录该图层信息
        {
          JBHT_NJBDX_single_frame_data_single_layer_info_t newLayerInfo;
          newLayerInfo.layer_name = NJBDXLayerEnglishName_GeoType;
          newLayerInfo.layer_geo_type = JBHT_layer_geo_type;
          newLayerInfo.polayer = poNewLayer;  // 此时的图层指针来自独立的数据集
          newLayerInfo.poSRS = poNewLayer->GetSpatialRef();

          NJBDX_single_frame_data_all_layers_info_entity.vNJBDX_single_frame_data_single_layer_info.push_back(newLayerInfo);

          single_frame_data_logger->info("函数[{}]：创建NJBDX图层 [{}] 成功 (来自 JBHT图层 [{}])",
            __FUNCTION__, NJBDXLayerEnglishName_GeoType, JBHTLayerName);
        }
      }
      else
      {
        //  已经创建过同名 NJBDX 图层，则打印日志不再创建
        single_frame_data_logger->info("函数[{}]：NJBDX图层 [{}] 已创建过，跳过重复创建。", __FUNCTION__, NJBDXLayerEnglishName_GeoType);
      }
    } // end for (auto& singleNJBDXLayerMapping ...)
#pragma endregion

  } // end for (auto& JBHTLayerInfo ...)
#pragma endregion

#pragma region "3 关闭所有的数据集然后再以目录的方式打开"
  //  对 createdDatasets 中的数据集执行 GDALClose()
  for (const auto& JBHT_createdDataset : createdDatasets)
  {
    GDALClose(JBHT_createdDataset.second);
  }

  //  以更新方式打开整个数据目录（目录下存在多个Shapefile），后续将对图层进行添加要素
  GDALDataset* poSingleFrameNJBDXDataSet = (GDALDataset*)GDALOpenEx(NJBDX_str_output_data_path.c_str(), GDAL_OF_UPDATE, NULL, NULL, NULL);
  //  文件不存在或打开失败
  if (poSingleFrameNJBDXDataSet == NULL)
  {
    single_frame_data_logger->error("函数[{}]：使用GDALOpenEx打开数据集{}失败，可能指定目录中不存在有效的shapefile数据。", __FUNCTION__, NJBDX_str_output_data_path);
    //  日志：输出统计信息
    single_frame_data_logger->info("函数[{}]：已完成 NJBDX Shapefile 图层的创建，共创建(或复用) 0 个图层。", __FUNCTION__);
    //  日志：结束
    single_frame_data_logger->info("********函数[{}]日志结束--->在目录{}中创建 NJBDX Shapefile 图层********", __FUNCTION__, NJBDX_str_output_data_path);
    return false;
  }
  else
  {
    //  日志：输出统计信息
    single_frame_data_logger->info("函数[{}]：已完成 NJBDX Shapefile 图层的创建，共创建(或复用) {} 个图层。", __FUNCTION__, createdDatasets.size());
    single_frame_data_logger->info("********函数[{}]日志结束--->在目录{}中创建 NJBDX Shapefile 图层********", __FUNCTION__, NJBDX_str_output_data_path);
  }

  //  更新之前保存的图层指针,因为之前存入的图层指针来自已关闭的数据集，现在通过新打开的数据集重新获取各个图层的指针
  for (auto& layerInfo : NJBDX_single_frame_data_all_layers_info_entity.vNJBDX_single_frame_data_single_layer_info)
  {
    OGRLayer* updatedLayer = poSingleFrameNJBDXDataSet->GetLayerByName(layerInfo.layer_name.c_str());
    if (updatedLayer)
    {
      layerInfo.polayer = updatedLayer;
      layerInfo.poSRS = updatedLayer->GetSpatialRef();
    }
    else
    {
      single_frame_data_logger->warn("函数[{}]：重新打开数据集后，图层[{}]为空。", __FUNCTION__, layerInfo.layer_name);
    }
  }

  //  Flush 缓存并关闭数据集，释放文件锁
  poSingleFrameNJBDXDataSet->FlushCache();
  //  保存以目录方式打开的数据集指针
  NJBDX_single_frame_data_all_layers_info_entity.NJBDX_single_frame_data_poDS = poSingleFrameNJBDXDataSet;
#pragma endregion

  //  日志：结束
  single_frame_data_logger->info("********函数[{}]：日志结束--->在目录{}中创建 NJBDX Shapefile 图层********", __FUNCTION__, NJBDX_str_output_data_path);
  return true;
}

//  检查NJBDX数据集中的有效图层是否为空
bool qgs_JBHT_NJBDX_semantic_fusion::JBHT_Check_NJBDX_all_layers_info(
  const JBHT_NJBDX_single_frame_data_all_layers_info_t& NJBDX_single_frame_data_all_layers_info_entity)
{
  if (NJBDX_single_frame_data_all_layers_info_entity.vNJBDX_single_frame_data_single_layer_info.size() == 0)
  {
    return false;
  }
  return true;
}

void qgs_JBHT_NJBDX_semantic_fusion::JBHT_Close_NJBDX_all_layers_info(
  JBHT_NJBDX_single_frame_data_all_layers_info_t& NJBDX_single_frame_data_all_layers_info_entity)
{
  GDALDataset* poDataset = NJBDX_single_frame_data_all_layers_info_entity.NJBDX_single_frame_data_poDS;
  if (poDataset)
  {
    // 倒序遍历图层，避免在删除图层后导致后面图层索引错乱
    for (int i = poDataset->GetLayerCount() - 1; i >= 0; --i)
    {
      OGRLayer* poLayer = poDataset->GetLayer(i);
      if (poLayer)
      {
        // 获取要素数量
        GIntBig nFeatureCount = poLayer->GetFeatureCount();
        // 如果图层要素数为 0，则删除该图层
        if (nFeatureCount == 0)
        {
          // 删除图层。注意需要确认当前驱动是否支持 DeleteLayer
          poDataset->DeleteLayer(i);
        }
      }
    }

    // 最后关闭数据集并将指针置空
    GDALClose(poDataset);
    NJBDX_single_frame_data_all_layers_info_entity.NJBDX_single_frame_data_poDS = nullptr;
  }
}









//  提取图层名称
std::string qgs_JBHT_NJBDX_semantic_fusion::JBHT_Extract_LayerName(
  const std::string& layerName,
  const JBHT_Layers_Fields_Info_Json_t& JBHT_Layers_Fields_Info_Json_entity,
  std::shared_ptr<spdlog::logger> logger)
{
  // 如果传入的 layerName 为空，直接返回
  if (layerName.empty())
  {
    logger->warn("函数[{}]：传入的 layerName 为空字符串，即矢量图层名称为空。", __FUNCTION__);
    return "";
  }

  //  遍历配置文件中所有图层的配置信息
  for (const auto& layerFields : JBHT_Layers_Fields_Info_Json_entity.vJBHT_Layers_Fields)
  {
    //  如果配置中的 JBHT_Layer_Name 为空，直接跳过
    if (layerFields.JBHT_Layer_Name.empty())
    {
      logger->warn("函数[{}]：JBHT_Layers_Fields_Info.json配置文件中某个 JBHT_Layer_Name 为空字符串，跳过矢量图层名称提取处理。", __FUNCTION__);
      continue;
    }

    /*
    Notes:杨小兵-2025-02-16
      1、构造正则表达式，std::regex::icase 表示大小写不敏感，如果想要让匹配变成大小写敏感，只需要去掉正则表达式构造时传入的 std::regex::icase 标志即可
      //std::regex re(layerFields.JBHT_Layer_Name, std::regex::icase);
    */
    std::regex re(layerFields.JBHT_Layer_Name);

    //  使用 std::regex_search 来检查 layerName 是否包含该模式
    if (std::regex_search(layerName, re))
    {
      // 如果匹配成功，可以根据业务需求做更多处理
      logger->info("函数[{}]：图层名称[{}] 与JBHT_Layers_Fields_Info.json配置文件中的[{}] 匹配成功。",
        __FUNCTION__, layerName, layerFields.JBHT_Layer_Name);

      //  例如可以直接返回匹配到的 JBHT_Layer_Name
      return layerFields.JBHT_Layer_Name;
    }
  }

  //  如果遍历完也没有找到匹配的配置信息
  logger->info("函数[{}]：图层名称[{}] 未在JBHT_Layers_Fields_Info.json配置文件中找到匹配项。", __FUNCTION__, layerName);
  return "";
}


//  辅助函数：将OGRwkbGeometryType映射到字符串
std::string qgs_JBHT_NJBDX_semantic_fusion::JBHT_OGRGeometryType2String(const OGRwkbGeometryType& GeoType)
{
  //  这里将LineString修改为了Line
  static const std::unordered_map<OGRwkbGeometryType, std::string> typeMap = {
    {wkbPoint,      "Point"},
    {wkbMultiPoint, "MultiPoint"},
    {wkbLineString, "Line"},
    {wkbMultiLineString, "MultiLineString"},
    {wkbPolygon,    "Polygon"},
    {wkbMultiPolygon, "MultiPolygon"},
    {wkbGeometryCollection, "GeometryCollection"}
    // 根据需要添加更多类型
  };

  auto it = typeMap.find(GeoType);
  if (it != typeMap.end())
  {
    return it->second;
  }
  else
  {
    throw std::invalid_argument("未知的 GDAL 几何类型: " + GeoType);
  }
}

//  辅助函数：从过滤条件中提取所有字段名称,该函数使用正则表达式，匹配所有形如 "字段名" 后面紧跟比较运算符的模式
std::vector<std::string> qgs_JBHT_NJBDX_semantic_fusion::extractFieldNames(const std::string& filter)
{
  std::vector<std::string> fieldNames;
  // 正则模式：匹配双引号中的内容，后面跟空白和比较运算符（=, !=, <, >, <=, >=）
  std::regex re("\"([^\"]+)\"\\s*(=|!=|<|>|<=|>=)");
  std::smatch match;
  std::string::const_iterator searchStart(filter.cbegin());
  while (std::regex_search(searchStart, filter.cend(), match, re))
  {
    // match[1] 为双引号内的字段名称
    fieldNames.push_back(match[1].str());
    searchStart = match.suffix().first;
  }
  return fieldNames;
}

#pragma endregion
